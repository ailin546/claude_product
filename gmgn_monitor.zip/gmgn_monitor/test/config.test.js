import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { applyOverrides, loadDotEnv, mergeDeep, resolveEnv } from "../src/config.js";

test("mergeDeep returns fresh default objects", () => {
  const base = {
    monitor: {
      intervalSeconds: 300
    },
    targets: [{ enabled: false }]
  };

  const merged = mergeDeep(base, {});
  merged.monitor.intervalSeconds = 1;
  merged.targets[0].enabled = true;

  assert.equal(base.monitor.intervalSeconds, 300);
  assert.equal(base.targets[0].enabled, false);
});

test("applyOverrides updates nested config values and parses numbers", () => {
  const config = {
    monitor: {
      intervalSeconds: 300,
      lookbackSeconds: 3600
    },
    thresholds: {
      minVolumeH1Usd: 2_000_000
    },
    targets: [],
    conditions: [],
    notifiers: {
      telegram: {
        enabled: false,
        botToken: "token",
        chatId: "chat"
      }
    },
    actions: {
      trade: {
        enabled: false,
        mode: "dry-run",
        args: []
      }
    }
  };

  const result = applyOverrides(config, [
    "thresholds.minVolumeH1Usd=3000000",
    "monitor.intervalSeconds=60",
    "notifiers.telegram.enabled=true"
  ]);

  assert.equal(result.thresholds.minVolumeH1Usd, 3_000_000);
  assert.equal(result.monitor.intervalSeconds, 60);
  assert.equal(result.notifiers.telegram.enabled, true);
});

test("resolveEnv supports fallback values", () => {
  const original = process.env.TEST_RPC_URL;
  delete process.env.TEST_RPC_URL;

  try {
    assert.equal(
      resolveEnv("${TEST_RPC_URL:-https://public.example}"),
      "https://public.example"
    );

    process.env.TEST_RPC_URL = "https://private.example";
    assert.equal(
      resolveEnv("${TEST_RPC_URL:-https://public.example}"),
      "https://private.example"
    );
  } finally {
    if (original === undefined) {
      delete process.env.TEST_RPC_URL;
    } else {
      process.env.TEST_RPC_URL = original;
    }
  }
});

test("loadDotEnv loads missing environment variables", async () => {
  const dir = await mkdtemp(path.join(tmpdir(), "token-watch-env-"));
  const original = process.env.TEST_GMGN_KEY;
  delete process.env.TEST_GMGN_KEY;

  try {
    await writeFile(path.join(dir, ".env"), "TEST_GMGN_KEY=abc123\n", "utf8");
    await loadDotEnv(dir);
    assert.equal(process.env.TEST_GMGN_KEY, "abc123");
  } finally {
    if (original === undefined) {
      delete process.env.TEST_GMGN_KEY;
    } else {
      process.env.TEST_GMGN_KEY = original;
    }
    await rm(dir, { recursive: true, force: true });
  }
});
