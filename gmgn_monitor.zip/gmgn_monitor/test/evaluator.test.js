import assert from "node:assert/strict";
import test from "node:test";
import { evaluatePair, evaluatePairWithConditions, resolveConditions, resolveThresholds } from "../src/evaluator.js";

const thresholds = {
  minVolumeH1Usd: 2_000_000,
  maxMarketCapUsd: 10_000_000,
  minUniqueWalletsH1: 1_000
};

test("alerts when all three thresholds are strictly satisfied", () => {
  const result = evaluatePair({
    pair: {
      volumeH1Usd: 2_000_001,
      marketCapUsd: 9_999_999
    },
    uniqueWalletsH1: 1_001,
    thresholds
  });

  assert.equal(result.shouldAlert, true);
  assert.deepEqual(result.checks, {
    volume: true,
    marketCap: true,
    uniqueWallets: true
  });
});

test("does not alert at equality boundaries", () => {
  const result = evaluatePair({
    pair: {
      volumeH1Usd: 2_000_000,
      marketCapUsd: 10_000_000
    },
    uniqueWalletsH1: 1_000,
    thresholds
  });

  assert.equal(result.shouldAlert, false);
  assert.deepEqual(result.checks, {
    volume: false,
    marketCap: false,
    uniqueWallets: false
  });
});

test("does not alert when market cap is missing", () => {
  const result = evaluatePair({
    pair: {
      volumeH1Usd: 3_000_000,
      marketCapUsd: null
    },
    uniqueWalletsH1: 2_000,
    thresholds
  });

  assert.equal(result.shouldAlert, false);
  assert.equal(result.checks.marketCap, false);
});

test("supports configurable extra conditions", () => {
  const result = evaluatePairWithConditions({
    pair: {
      volumeH1Usd: 3_000_000,
      marketCapUsd: 9_000_000,
      liquidityUsd: 750_000
    },
    uniqueWalletsH1: 1_500,
    context: { thresholds },
    conditions: [
      { id: "volume", metric: "volumeH1Usd", operator: ">", valueFrom: "thresholds.minVolumeH1Usd" },
      { id: "liquidity", metric: "liquidityUsd", operator: ">=", value: 500_000 }
    ]
  });

  assert.equal(result.shouldAlert, true);
  assert.equal(result.checks.volume, true);
  assert.equal(result.checks.liquidity, true);
});

test("fails configurable conditions with a readable reason", () => {
  const result = evaluatePairWithConditions({
    pair: {
      volumeH1Usd: 3_000_000,
      marketCapUsd: 9_000_000,
      liquidityUsd: 100_000
    },
    uniqueWalletsH1: 1_500,
    conditions: [
      { id: "liquidity", label: "liquidity", metric: "liquidityUsd", operator: ">=", value: 500_000 }
    ]
  });

  assert.equal(result.shouldAlert, false);
  assert.equal(result.checks.liquidity, false);
  assert.match(result.reasons[0], /liquidity 100000 >= 500000 not satisfied/);
});

test("chain thresholds override global thresholds", () => {
  const result = evaluatePairWithConditions({
    pair: {
      volumeH1Usd: 1_600_000,
      marketCapUsd: 7_000_000
    },
    uniqueWalletsH1: 900,
    context: {
      thresholds,
      chain: {
        thresholds: {
          minVolumeH1Usd: 1_500_000,
          maxMarketCapUsd: 8_000_000,
          minUniqueWalletsH1: 800
        }
      }
    }
  });

  assert.equal(result.shouldAlert, true);
});

test("target thresholds override chain thresholds", () => {
  const merged = resolveThresholds({
    thresholds,
    chain: {
      thresholds: {
        minVolumeH1Usd: 1_500_000
      }
    },
    target: {
      thresholds: {
        minVolumeH1Usd: 4_000_000
      }
    }
  });

  assert.equal(merged.minVolumeH1Usd, 4_000_000);
});

test("conditions resolve target before chain before global", () => {
  const globalConditions = [{ id: "global", metric: "volumeH1Usd" }];
  const chainConditions = [{ id: "chain", metric: "volumeH1Usd" }];
  const targetConditions = [{ id: "target", metric: "volumeH1Usd" }];

  assert.equal(resolveConditions({
    config: { conditions: globalConditions },
    chain: { conditions: chainConditions },
    target: { conditions: targetConditions }
  })[0].id, "target");

  assert.equal(resolveConditions({
    config: { conditions: globalConditions },
    chain: { conditions: chainConditions },
    target: {}
  })[0].id, "chain");

  assert.equal(resolveConditions({
    config: { conditions: globalConditions },
    chain: {},
    target: {}
  })[0].id, "global");
});

test("exists operator only requires a present metric", () => {
  const result = evaluatePairWithConditions({
    pair: {
      volumeH1Usd: 3_000_000
    },
    uniqueWalletsH1: 0,
    conditions: [
      { id: "volumeExists", metric: "volumeH1Usd", operator: "exists" }
    ]
  });

  assert.equal(result.shouldAlert, true);
});
