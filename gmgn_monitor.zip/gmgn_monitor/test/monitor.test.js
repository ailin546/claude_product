import assert from "node:assert/strict";
import test from "node:test";
import { TokenMonitor } from "../src/monitor.js";

test("monitor normalizes sol alias and uses solana chain thresholds", async () => {
  const dexCalls = [];
  const dexClient = {
    async getPair(chainId, pairAddress) {
      dexCalls.push({ chainId, pairAddress });
      return {
        chainId,
        dexId: "raydium",
        pairAddress,
        baseToken: { address: "token-address", symbol: "TKN" },
        quoteToken: { address: "quote-address", symbol: "SOL" },
        priceUsd: "1",
        volume: { h1: 2_400_000 },
        marketCap: 9_000_000,
        liquidity: { usd: 700_000 },
        url: "https://dexscreener.com/solana/pair-address"
      };
    }
  };
  const rpcFactory = (chain) => {
    assert.equal(chain.kind, "solana");
    return {
      async request(method) {
        if (method === "getSignaturesForAddress") {
          return [
            { signature: "sig1", blockTime: Math.floor(Date.now() / 1000) },
            { signature: "sig2", blockTime: Math.floor(Date.now() / 1000) }
          ];
        }
        throw new Error(`Unexpected request ${method}`);
      },
      async batch(calls) {
        return calls.map((call) => ({
          transaction: {
            message: {
              accountKeys: [call.params[0] === "sig1" ? "wallet-1" : "wallet-2"]
            }
          }
        }));
      }
    };
  };
  const monitor = new TokenMonitor({
    config: {
      monitor: {
        lookbackSeconds: 3600,
        maxPairsPerToken: 3,
        alertCooldownSeconds: 3600
      },
      thresholds: {
        minVolumeH1Usd: 2_000_000,
        maxMarketCapUsd: 10_000_000,
        minUniqueWalletsH1: 1
      },
      conditions: [],
      chainAliases: {
        sol: "solana"
      },
      chains: {
        solana: {
          kind: "solana",
          rpcUrl: "https://solana-rpc.example",
          thresholds: {
            minVolumeH1Usd: 2_500_000,
            maxMarketCapUsd: 10_000_000,
            minUniqueWalletsH1: 1
          }
        }
      },
      targets: [
        {
          enabled: true,
          chainId: "sol",
          pairAddress: "pair-address"
        }
      ],
      notifiers: {
        console: { enabled: false }
      },
      actions: {
        trade: { enabled: false }
      }
    },
    dexClient,
    rpcFactory,
    notifyFn: async () => {
      throw new Error("should not notify");
    },
    actionFn: async () => {
      throw new Error("should not run actions");
    }
  });

  const [result] = await monitor.runOnce();

  assert.deepEqual(dexCalls, [{ chainId: "solana", pairAddress: "pair-address" }]);
  assert.equal(result.status, "ok");
  assert.equal(result.pair.chainId, "solana");
  assert.equal(result.evaluation.checks.volume, false);
  assert.match(result.evaluation.reasons[0], /2500000/);
});
