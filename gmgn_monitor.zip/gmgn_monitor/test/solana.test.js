import assert from "node:assert/strict";
import test from "node:test";
import { collectRecentSignatures, countUniqueSolanaWallets } from "../src/solana.js";

test("collectRecentSignatures stops at the lookback cutoff", async () => {
  const rpc = {
    async request(method, params) {
      assert.equal(method, "getSignaturesForAddress");
      assert.equal(params[0], "pair-address");
      return [
        { signature: "sig1", blockTime: 200 },
        { signature: "sig2", blockTime: 150 },
        { signature: "old", blockTime: 90 }
      ];
    }
  };

  const signatures = await collectRecentSignatures({
    rpc,
    address: "pair-address",
    cutoffSeconds: 100
  });

  assert.deepEqual(signatures.map((item) => item.signature), ["sig1", "sig2"]);
});

test("countUniqueSolanaWallets counts unique fee payers", async () => {
  const rpc = {
    async request(method) {
      if (method === "getSignaturesForAddress") {
        return [
          { signature: "sig1", blockTime: Math.floor(Date.now() / 1000) },
          { signature: "sig2", blockTime: Math.floor(Date.now() / 1000) },
          { signature: "sig3", blockTime: Math.floor(Date.now() / 1000) }
        ];
      }
      throw new Error(`Unexpected request ${method}`);
    },
    async batch(calls) {
      return calls.map((call) => ({
        transaction: {
          message: {
            accountKeys: [
              call.params[0] === "sig3" ? "wallet-2" : "wallet-1"
            ]
          }
        }
      }));
    }
  };

  const stats = await countUniqueSolanaWallets({
    rpc,
    pairAddress: "pair-address",
    lookbackSeconds: 3600
  });

  assert.equal(stats.uniqueWallets, 2);
  assert.equal(stats.scannedSignatures, 3);
});
