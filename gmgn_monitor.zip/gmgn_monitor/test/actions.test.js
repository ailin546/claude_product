import assert from "node:assert/strict";
import test from "node:test";
import { buildTradeAction, runActions } from "../src/actions.js";

test("buildTradeAction marks non-live actions as dry-run", () => {
  const action = buildTradeAction({ symbol: "TKN/WETH" }, {
    command: "gmgn-cli",
    args: ["swap"]
  }, true);

  assert.equal(action.type, "trade");
  assert.equal(action.mode, "dry-run");
  assert.equal(action.command, "gmgn-cli");
});

test("runActions returns no actions when trade action is disabled", async () => {
  const actions = await runActions({}, {
    actions: {
      trade: {
        enabled: false
      }
    }
  });

  assert.deepEqual(actions, []);
});

test("runActions prepares dry-run trade action without command", async () => {
  const actions = await runActions({ symbol: "TKN/WETH", chainId: "base", pairAddress: "0xpair" }, {
    monitor: { dryRun: true },
    actions: {
      trade: {
        enabled: true,
        mode: "dry-run",
        args: [],
        logDryRun: false
      }
    }
  });

  assert.equal(actions.length, 1);
  assert.equal(actions[0].mode, "dry-run");
});
