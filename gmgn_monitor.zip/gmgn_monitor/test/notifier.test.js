import assert from "node:assert/strict";
import test from "node:test";
import { formatTelegramMessage, notify } from "../src/notifier.js";

test("dry-run mode suppresses webhook delivery", async () => {
  let webhookCalls = 0;

  await notify({ symbol: "TKN/WETH", chainId: "base", pairAddress: "0xpair" }, {
    monitor: { dryRun: true },
    notifiers: {
      console: { enabled: false },
      webhook: { enabled: true, url: "https://example.invalid" }
    }
  }, {
    async fetchImpl() {
      webhookCalls += 1;
      return { ok: true };
    }
  });

  assert.equal(webhookCalls, 0);
});

test("dry-run mode suppresses telegram delivery", async () => {
  let telegramCalls = 0;

  await notify({ symbol: "TKN/WETH", chainId: "base", pairAddress: "0xpair" }, {
    monitor: { dryRun: true },
    notifiers: {
      console: { enabled: false },
      telegram: { enabled: true, botToken: "token", chatId: "chat" }
    }
  }, {
    async fetchImpl() {
      telegramCalls += 1;
      return { ok: true };
    }
  });

  assert.equal(telegramCalls, 0);
});

test("sends telegram alerts with expected payload", async () => {
  const requests = [];
  const alert = {
    symbol: "TKN/WETH",
    chainId: "base",
    pairAddress: "0xpair",
    tokenAddress: "0xtoken",
    volumeH1Usd: 2_500_000,
    marketCapUsd: 9_000_000,
    uniqueWalletsH1: 1_250,
    liquidityUsd: 700_000,
    url: "https://dexscreener.com/base/0xpair"
  };

  await notify(alert, {
    monitor: { dryRun: false },
    notifiers: {
      console: { enabled: false },
      telegram: { enabled: true, botToken: "bot-token", chatId: "chat-id" }
    }
  }, {
    async fetchImpl(url, options) {
      requests.push({ url, options });
      return { ok: true };
    }
  });

  assert.equal(requests.length, 1);
  assert.equal(requests[0].url, "https://api.telegram.org/botbot-token/sendMessage");
  assert.equal(JSON.parse(requests[0].options.body).chat_id, "chat-id");
  assert.match(JSON.parse(requests[0].options.body).text, /1h volume: \$2,500,000/);
});

test("formats telegram message without markdown-specific escaping needs", () => {
  const message = formatTelegramMessage({
    symbol: "TKN/WETH",
    chainId: "base",
    pairAddress: "0xpair",
    tokenAddress: "0xtoken",
    volumeH1Usd: 2_500_000,
    marketCapUsd: 9_000_000,
    uniqueWalletsH1: 1_250,
    liquidityUsd: 700_000
  });

  assert.match(message, /Token monitor alert/);
  assert.match(message, /TKN\/WETH on base/);
});
