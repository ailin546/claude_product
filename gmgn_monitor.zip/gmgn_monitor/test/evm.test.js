import assert from "node:assert/strict";
import test from "node:test";
import { findFirstBlockAtOrAfter, getSwapLogsChunked, SWAP_TOPICS } from "../src/evm.js";

test("findFirstBlockAtOrAfter uses block timestamps with binary search", async () => {
  const timestamps = [100, 110, 120, 130, 140, 150];
  const calls = [];
  const rpc = {
    async request(method, params) {
      calls.push({ method, params });
      const blockNumber = Number.parseInt(params[0], 16);
      return {
        number: params[0],
        timestamp: `0x${timestamps[blockNumber].toString(16)}`
      };
    }
  };

  const block = await findFirstBlockAtOrAfter(rpc, 125, 0, 5);

  assert.equal(block, 3);
  assert.ok(calls.length <= 3);
});

test("uses known Uniswap V2 and V3 swap topic0 hashes", () => {
  assert.deepEqual(SWAP_TOPICS, [
    "0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822",
    "0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67"
  ]);
});

test("getSwapLogsChunked splits large block ranges", async () => {
  const requests = [];
  const rpc = {
    async request(method, params) {
      requests.push({ method, params });
      return [{ transactionHash: `0x${requests.length}` }];
    }
  };

  const logs = await getSwapLogsChunked({
    rpc,
    pairAddress: "0xabc",
    fromBlock: 10,
    toBlock: 24,
    logChunkSize: 5
  });

  assert.equal(logs.length, 3);
  assert.deepEqual(requests.map((request) => request.params[0].fromBlock), ["0xa", "0xf", "0x14"]);
  assert.deepEqual(requests.map((request) => request.params[0].toBlock), ["0xe", "0x13", "0x18"]);
  assert.deepEqual(requests[0].params[0].topics, [SWAP_TOPICS]);
});
