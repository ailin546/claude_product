import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import test from "node:test";

test("web server serves the console and status api", async () => {
  const port = await getFreePort();
  const child = spawn(process.execPath, ["src/web.js", "--config", "config.example.json", "--port", String(port)], {
    cwd: process.cwd(),
    stdio: ["ignore", "pipe", "pipe"]
  });

  try {
    await waitForServer(child.stdout);
    const [home, app, statusResponse] = await Promise.all([
      fetch(`http://127.0.0.1:${port}/`).then((response) => response.text()),
      fetch(`http://127.0.0.1:${port}/app.js`).then((response) => response.text()),
      fetch(`http://127.0.0.1:${port}/api/status`)
    ]);
    const status = await statusResponse.json();

    assert.match(home, /Token Watch Console/);
    assert.match(home, /链与筛选条件/);
    assert.match(home, /Telegram 提醒/);
    assert.match(app, /renderChainForms/);
    assert.match(app, /data-path/);
    assert.equal(status.running, false);
    assert.deepEqual(status.chains, ["ethereum", "bsc", "solana"]);
  } finally {
    child.kill("SIGTERM");
  }
});

function waitForServer(stream) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("web server did not start")), 5000);
    stream.on("data", (chunk) => {
      if (String(chunk).includes("token-watch web listening")) {
        clearTimeout(timeout);
        resolve();
      }
    });
  });
}

function getFreePort() {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
    server.on("error", reject);
  });
}
