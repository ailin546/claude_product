import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";

test("CLI rejects --config without a path", () => {
  const result = spawnSync(process.execPath, ["src/index.js", "--config"], {
    encoding: "utf8"
  });

  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /--config requires a config file path/);
});
