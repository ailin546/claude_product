#!/usr/bin/env node

import { readFile, rm } from "node:fs/promises";

const pidFile = process.env.PID_FILE ?? "logs/web.pid";

try {
  const pid = Number((await readFile(pidFile, "utf8")).trim());
  if (Number.isInteger(pid)) {
    process.kill(pid, "SIGTERM");
    console.log(`token-watch web stopped: pid=${pid}`);
  }
  await rm(pidFile, { force: true });
} catch (error) {
  if (error.code === "ENOENT") {
    console.log("token-watch web is not running");
  } else if (error.code === "ESRCH") {
    await rm(pidFile, { force: true });
    console.log("token-watch web pid was stale");
  } else {
    throw error;
  }
}
