#!/usr/bin/env node

import { spawn } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const cwd = process.cwd();
const port = process.env.PORT ?? "8799";
const host = process.env.HOST ?? "127.0.0.1";
const config = process.env.CONFIG ?? "config.example.json";
const logFile = process.env.LOG_FILE ?? "logs/web.log";
const pidFile = process.env.PID_FILE ?? "logs/web.pid";

await mkdir(path.dirname(path.resolve(logFile)), { recursive: true });

const existingPid = await readExistingPid(pidFile);
if (existingPid && isRunning(existingPid)) {
  console.log(`token-watch web already running: pid=${existingPid}`);
  process.exit(0);
}

const child = spawn(process.execPath, [
  "src/web.js",
  "--config",
  config,
  "--host",
  host,
  "--port",
  port,
  "--log-file",
  logFile
], {
  cwd,
  detached: true,
  stdio: ["ignore", "ignore", "ignore"]
});

child.unref();
await writeFile(pidFile, `${child.pid}\n`, "utf8");
console.log(`token-watch web started: pid=${child.pid} url=http://${host}:${port}`);

async function readExistingPid(file) {
  try {
    const raw = await readFile(file, "utf8");
    const pid = Number(raw.trim());
    return Number.isInteger(pid) ? pid : null;
  } catch {
    return null;
  }
}

function isRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
