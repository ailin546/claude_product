const CHAIN_LABELS = {
  ethereum: "Ethereum",
  bsc: "BSC",
  solana: "Solana"
};

const els = {
  configPath: document.querySelector("#configPath"),
  runningState: document.querySelector("#runningState"),
  interval: document.querySelector("#interval"),
  dryRun: document.querySelector("#dryRun"),
  lastRun: document.querySelector("#lastRun"),
  results: document.querySelector("#results"),
  resultCount: document.querySelector("#resultCount"),
  targets: document.querySelector("#targets"),
  targetForms: document.querySelector("#targetForms"),
  chainForms: document.querySelector("#chainForms"),
  syncThresholdsBtn: document.querySelector("#syncThresholdsBtn"),
  events: document.querySelector("#events"),
  eventCount: document.querySelector("#eventCount"),
  configEditor: document.querySelector("#configEditor"),
  refreshBtn: document.querySelector("#refreshBtn"),
  runBtn: document.querySelector("#runBtn"),
  toggleBtn: document.querySelector("#toggleBtn"),
  saveBtn: document.querySelector("#saveBtn"),
  topSaveBtn: document.querySelector("#topSaveBtn"),
  saveState: document.querySelector("#saveState"),
  addTargetBtn: document.querySelector("#addTargetBtn"),
  toast: document.querySelector("#toast")
};

let statusCache = null;
let configModel = null;
let lastResults = [];
let toastTimer = null;
let applyingForm = false;

els.refreshBtn.addEventListener("click", refreshAll);
els.runBtn.addEventListener("click", runOnce);
els.toggleBtn.addEventListener("click", toggleMonitor);
els.saveBtn.addEventListener("click", saveConfig);
els.topSaveBtn.addEventListener("click", saveConfig);
els.addTargetBtn.addEventListener("click", addTarget);
els.syncThresholdsBtn.addEventListener("click", syncThresholdsToAllChains);
els.configEditor.addEventListener("input", syncFromJsonEditor);
document.addEventListener("input", handleFormInput);
document.addEventListener("change", handleFormInput);
document.addEventListener("click", handleDocumentClick);

await refreshAll();
setInterval(refreshStatus, 5000);

async function refreshAll() {
  await Promise.all([refreshConfig(), refreshStatus()]);
}

async function refreshConfig() {
  const data = await api("/api/config");
  els.configPath.textContent = data.path;
  configModel = JSON.parse(data.raw);
  renderConfigForm();
  markSaved();
}

async function refreshStatus() {
  const status = await api("/api/status");
  statusCache = status;
  renderStatus(status);
}

async function runOnce() {
  setBusy(true);
  try {
    const data = await api("/api/run-once", { method: "POST" });
    lastResults = data.results ?? [];
    renderResults(lastResults);
    renderStatus(data.status);
    showToast(`完成：检查 ${lastResults.length} 个候选，命中 ${lastResults.filter((item) => item.status === "alert").length} 个`);
  } catch (error) {
    showToast(error.message);
  } finally {
    setBusy(false);
  }
}

async function toggleMonitor() {
  const running = Boolean(statusCache?.running);
  const data = await api(running ? "/api/stop" : "/api/start", { method: "POST" });
  renderStatus(data.status);
  showToast(running ? "监控已停止" : "监控已启动");
}

async function saveConfig() {
  if (!configModel) return;

  syncModelFromRenderedForms();
  const gmgnKey = configModel.gmgn?.apiKey?.trim?.() ?? "";
  if (configModel.discovery?.gmgnTrending?.enabled && (!gmgnKey || /^\$\{.+\}$/.test(gmgnKey))) {
    showToast("请先填写真实的 GMGN API Key，再保存运行");
    return;
  }

  const raw = JSON.stringify(configModel, null, 2);

  const data = await api("/api/config", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ raw })
  });
  renderStatus(data.status);
  renderConfigForm();
  markSaved();
  showToast("配置已保存");
}

function renderConfigForm() {
  applyingForm = true;
  for (const input of document.querySelectorAll("[data-path]")) {
    setInputValue(input, getByPath(configModel, input.dataset.path));
  }
  renderChainForms();
  renderTargetForms();
  els.configEditor.value = JSON.stringify(configModel, null, 2);
  applyingForm = false;
}

function renderChainForms() {
  const chains = configModel.chains ?? {};
  els.chainForms.innerHTML = Object.entries(chains).map(([chainId, chain]) => {
    const prefix = `chains.${chainId}`;
    return `
      <article class="chain-card" data-chain-id="${escapeHtml(chainId)}">
        <div class="chain-title">
          <div>
            <strong>${escapeHtml(CHAIN_LABELS[chainId] ?? chainId)}</strong>
            <span>${escapeHtml(chain.kind ?? "-")}</span>
          </div>
          <span class="pill">${escapeHtml(chainId)}</span>
        </div>
        <div class="form-grid compact">
          <label>
            <span>RPC URL</span>
            <input data-path="${prefix}.rpcUrl" type="text">
          </label>
          <label>
            <span>1h 交易额大于</span>
            <input data-path="${prefix}.thresholds.minVolumeH1Usd" type="number" min="0" step="1">
          </label>
          <label>
            <span>市值小于</span>
            <input data-path="${prefix}.thresholds.maxMarketCapUsd" type="number" min="0" step="1">
          </label>
          <label>
            <span>独立钱包大于</span>
            <input data-path="${prefix}.thresholds.minUniqueWalletsH1" type="number" min="0" step="1">
          </label>
          ${renderChainSpecificFields(chainId, chain, prefix)}
        </div>
      </article>
    `;
  }).join("");

  for (const input of els.chainForms.querySelectorAll("[data-path]")) {
    setInputValue(input, getByPath(configModel, input.dataset.path));
  }
}

function syncThresholdsToAllChains() {
  const chains = Object.keys(configModel.chains ?? {});
  const source = configModel.chains?.[chains[0]]?.thresholds;
  if (!source) {
    showToast("没有可同步的链条件");
    return;
  }

  for (const chainId of chains) {
    configModel.chains[chainId].thresholds = { ...source };
  }
  configModel.thresholds = { ...source };
  renderConfigForm();
  markDirty();
  showToast("已同步到所有链，记得保存配置");
}

function renderChainSpecificFields(chainId, chain, prefix) {
  if (chain.kind === "solana") {
    return `
      <label>
        <span>最大签名数</span>
        <input data-path="${prefix}.maxSignatures" type="number" min="1" step="1">
      </label>
      <label>
        <span>交易批量</span>
        <input data-path="${prefix}.transactionBatchSize" type="number" min="1" step="1">
      </label>
    `;
  }

  return `
    <label>
      <span>日志区块分片</span>
      <input data-path="${prefix}.logChunkSize" type="number" min="1" step="1">
    </label>
  `;
}

function renderTargetForms() {
  const targets = configModel.targets ?? [];
  if (targets.length === 0) {
    els.targetForms.innerHTML = `<p class="empty">自动选币模式不需要指定 token。这里仅用于临时盯某个 token 或 pair。</p>`;
    return;
  }

  els.targetForms.innerHTML = targets.map((target, index) => `
    <article class="target-form" data-target-index="${index}">
      <div class="target-form-head">
        <strong>${escapeHtml(target.label || `目标 ${index + 1}`)}</strong>
        <button data-remove-target="${index}" title="删除目标">删除</button>
      </div>
      <div class="form-grid compact">
        <label>
          <span>名称</span>
          <input data-target-path="${index}.label" type="text">
        </label>
        <label>
          <span>公链</span>
          <select data-target-path="${index}.chainId">
            ${chainOptions(target.chainId)}
          </select>
        </label>
        <label class="checkline">
          <input data-target-path="${index}.enabled" type="checkbox">
          <span>启用</span>
        </label>
        <label>
          <span>Token 地址</span>
          <input data-target-path="${index}.tokenAddress" type="text">
        </label>
        <label>
          <span>Pair 地址</span>
          <input data-target-path="${index}.pairAddress" type="text">
        </label>
      </div>
    </article>
  `).join("");

  for (const input of els.targetForms.querySelectorAll("[data-target-path]")) {
    const [index, ...path] = input.dataset.targetPath.split(".");
    setInputValue(input, getByPath(configModel.targets[Number(index)], path.join(".")));
  }
}

function chainOptions(selected) {
  return Object.keys(configModel.chains ?? {}).map((chainId) => `
    <option value="${escapeHtml(chainId)}" ${chainId === selected ? "selected" : ""}>${escapeHtml(CHAIN_LABELS[chainId] ?? chainId)}</option>
  `).join("");
}

function handleFormInput(event) {
  if (applyingForm) return;
  const input = event.target;

  if (input.matches("[data-path]")) {
    setByPath(configModel, input.dataset.path, readInputValue(input));
    updateJsonEditor();
    markDirty();
  }

  if (input.matches("[data-target-path]")) {
    const [index, ...path] = input.dataset.targetPath.split(".");
    setByPath(configModel.targets[Number(index)], path.join("."), readInputValue(input));
    updateJsonEditor();
    renderTargetSummary();
    markDirty();
  }
}

function handleDocumentClick(event) {
  const removeButton = event.target.closest("[data-remove-target]");
  if (!removeButton) return;

  const index = Number(removeButton.dataset.removeTarget);
  configModel.targets.splice(index, 1);
  renderTargetForms();
  renderTargetSummary();
  updateJsonEditor();
  markDirty();
}

function syncModelFromRenderedForms() {
  for (const input of document.querySelectorAll("[data-path]")) {
    setByPath(configModel, input.dataset.path, readInputValue(input));
  }

  for (const input of document.querySelectorAll("[data-target-path]")) {
    const [index, ...path] = input.dataset.targetPath.split(".");
    setByPath(configModel.targets[Number(index)], path.join("."), readInputValue(input));
  }
}

function syncFromJsonEditor() {
  if (applyingForm) return;

  try {
    configModel = JSON.parse(els.configEditor.value);
    renderConfigForm();
    markDirty();
  } catch {
    // Keep editing until JSON becomes valid.
  }
}

function addTarget() {
  configModel.targets ??= [];
  configModel.targets.push({
    label: "New target",
    enabled: true,
    chainId: "ethereum",
    tokenAddress: "",
    pairAddress: ""
  });
  renderTargetForms();
  renderTargetSummary();
  updateJsonEditor();
  markDirty();
}

function updateJsonEditor() {
  els.configEditor.value = JSON.stringify(configModel, null, 2);
}

function markDirty() {
  els.saveState.textContent = "未保存";
  els.saveState.classList.add("dirty");
}

function markSaved() {
  els.saveState.textContent = "已保存";
  els.saveState.classList.remove("dirty");
}

function renderStatus(status) {
  statusCache = status;
  els.runningState.textContent = status.running ? (status.busy ? "运行中" : "已启动") : "已停止";
  els.runningState.className = status.running ? "status-ok" : "";
  els.interval.textContent = `${status.intervalSeconds ?? "-"}s`;
  els.dryRun.textContent = status.dryRun ? "开启" : "关闭";
  els.lastRun.textContent = status.lastRunAt ? formatTime(status.lastRunAt) : "-";
  els.toggleBtn.textContent = status.running ? "停止" : "启动";
  els.toggleBtn.classList.toggle("primary", !status.running);
  els.runBtn.disabled = status.busy;
  els.eventCount.textContent = String(status.eventCount ?? 0);
  renderTargetSummary(status.targets ?? configModel?.targets ?? []);
  renderEvents(status.recentEvents ?? []);
}

function renderResults(results) {
  const alerts = results.filter((result) => result.status === "alert");
  els.resultCount.textContent = `${alerts.length} / ${results.length}`;

  if (results.length === 0) {
    els.results.innerHTML = `<p class="empty">还没有运行结果。点击“运行一次”开始筛选。</p>`;
    return;
  }

  if (alerts.length === 0) {
    els.results.innerHTML = `
      <p class="empty">本轮没有命中。候选已检查 ${results.length} 个，可以降低交易额、市值或钱包条件后再试。</p>
      ${renderRejectedResults(results.slice(0, 8))}
    `;
    return;
  }

  els.results.innerHTML = alerts.map(renderResultCard).join("");
}

function renderResultCard(result) {
  const pair = result.pair ?? {};
  const alert = result.alert ?? {};
  const tokenAddress = pair.tokenAddress ?? alert.tokenAddress ?? "-";
  const href = pair.url || alert.url || "";

  return `
    <article class="result-card">
      <div class="result-title">
        <div>
          <strong>${escapeHtml(pair.symbol ?? alert.symbol ?? "-")}</strong>
          <span>${escapeHtml(CHAIN_LABELS[pair.chainId] ?? pair.chainId ?? "-")}</span>
        </div>
        ${href ? `<a href="${escapeHtml(href)}" target="_blank" rel="noreferrer">GMGN</a>` : ""}
      </div>
      <div class="result-metrics">
        <div><span>1h 交易额</span><strong>${formatUsd(pair.volumeH1Usd ?? alert.volumeH1Usd)}</strong></div>
        <div><span>市值</span><strong>${formatUsd(pair.marketCapUsd ?? alert.marketCapUsd)}</strong></div>
        <div><span>钱包/持有人</span><strong>${formatNumber(result.walletStats?.uniqueWallets ?? alert.uniqueWalletsH1)}</strong></div>
        <div><span>流动性</span><strong>${formatUsd(pair.liquidityUsd ?? alert.liquidityUsd)}</strong></div>
      </div>
      <div class="condition-line">${renderConditionLine(result.evaluation?.details ?? [])}</div>
      <dl class="result-addresses">
        <dt>Token</dt>
        <dd>${escapeHtml(tokenAddress)}</dd>
        <dt>来源</dt>
        <dd>${escapeHtml(pair.source ?? "gmgnTrending")}</dd>
      </dl>
    </article>
  `;
}

function renderConditionLine(details) {
  if (!details.length) return "";
  return details.map((detail) => `
    <span>${escapeHtml(detail.label)}: ${formatRaw(detail.actual)} ${escapeHtml(detail.operator)} ${formatRaw(detail.expected)}</span>
  `).join("");
}

function renderRejectedResults(results) {
  if (results.length === 0) return "";

  return `
    <div class="rejected-list">
      ${results.map((result) => `
        <div class="rejected-item">
          <strong>${escapeHtml(result.pair?.symbol ?? "-")}</strong>
          <span>${escapeHtml((result.evaluation?.reasons ?? []).join("; ") || result.status)}</span>
        </div>
      `).join("")}
    </div>
  `;
}

function renderTargetSummary(targets = configModel?.targets ?? []) {
  const gmgn = configModel?.discovery?.gmgnTrending;
  const manualTargets = targets.filter((target) => target.enabled !== false);
  const chains = gmgn?.chains?.join(", ") || "-";

  const sourceHtml = `
    <article class="target">
      <strong>GMGN Trending</strong>
      <dl>
        <dt>状态</dt>
        <dd><span class="pill">${gmgn?.enabled ? "enabled" : "disabled"}</span></dd>
        <dt>链</dt>
        <dd>${escapeHtml(chains)}</dd>
        <dt>窗口</dt>
        <dd>${escapeHtml(gmgn?.interval ?? "-")}</dd>
        <dt>数量</dt>
        <dd>${escapeHtml(gmgn?.limit ?? "-")} / 链</dd>
      </dl>
    </article>
  `;

  const manualHtml = manualTargets.map((target) => `
    <article class="target">
      <strong>${escapeHtml(target.label || "Untitled target")}</strong>
      <dl>
        <dt>状态</dt>
        <dd><span class="pill">${target.enabled === false ? "disabled" : "enabled"}</span></dd>
        <dt>链</dt>
        <dd>${escapeHtml(target.chainId || "-")}</dd>
        <dt>Token</dt>
        <dd>${escapeHtml(target.tokenAddress || "-")}</dd>
        <dt>Pair</dt>
        <dd>${escapeHtml(target.pairAddress || "-")}</dd>
      </dl>
    </article>
  `).join("");

  els.targets.innerHTML = sourceHtml + (manualHtml ? `<p class="section-note">手动观察对象</p>${manualHtml}` : "");
}

function renderEvents(events) {
  if (events.length === 0) {
    els.events.innerHTML = `<p class="empty">暂无事件</p>`;
    return;
  }

  els.events.innerHTML = events.map((event) => `
    <article class="event">
      <div class="event-top">
        <span class="event-type status-${escapeHtml(event.status || "")}">${escapeHtml(event.type)}</span>
        <span class="event-time">${formatTime(event.at)}</span>
      </div>
      <div class="event-message">${escapeHtml(event.message || "")}</div>
    </article>
  `).join("");
}

function setInputValue(input, value) {
  if (input.type === "checkbox") {
    input.checked = Boolean(value);
  } else {
    input.value = value ?? "";
  }
}

function readInputValue(input) {
  if (input.type === "checkbox") {
    return input.checked;
  }
  if (input.type === "number") {
    return input.value === "" ? null : Number(input.value);
  }
  return input.value;
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  const text = await response.text();
  const data = text ? JSON.parse(text) : {};
  if (!response.ok) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }
  return data;
}

function setBusy(isBusy) {
  els.runBtn.disabled = isBusy;
  els.saveBtn.disabled = isBusy;
  els.topSaveBtn.disabled = isBusy;
  els.refreshBtn.disabled = isBusy;
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.hidden = true;
  }, 3200);
}

function formatTime(value) {
  return new Intl.DateTimeFormat("zh-CN", {
    hour12: false,
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).format(new Date(value));
}

function formatUsd(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `$${formatNumber(number)}` : "-";
}

function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "-";
  return number.toLocaleString("en-US", { maximumFractionDigits: 6 });
}

function formatRaw(value) {
  const number = Number(value);
  if (Number.isFinite(number)) return formatNumber(number);
  return escapeHtml(value ?? "-");
}

function getByPath(source, keyPath) {
  return String(keyPath)
    .split(".")
    .filter(Boolean)
    .reduce((value, key) => (value === null || value === undefined ? undefined : value[key]), source);
}

function setByPath(target, keyPath, value) {
  const parts = String(keyPath).split(".").filter(Boolean);
  let cursor = target;

  for (const key of parts.slice(0, -1)) {
    if (!cursor[key] || typeof cursor[key] !== "object") {
      cursor[key] = {};
    }
    cursor = cursor[key];
  }

  cursor[parts.at(-1)] = value;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
