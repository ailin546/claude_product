const DEFAULT_CONDITIONS = [
  {
    id: "volume",
    metric: "volumeH1Usd",
    operator: ">",
    valueFrom: "thresholds.minVolumeH1Usd"
  },
  {
    id: "marketCap",
    metric: "marketCapUsd",
    operator: "<",
    valueFrom: "thresholds.maxMarketCapUsd"
  },
  {
    id: "uniqueWallets",
    metric: "uniqueWalletsH1",
    operator: ">",
    valueFrom: "thresholds.minUniqueWalletsH1"
  }
];

export function evaluatePair({ pair, uniqueWalletsH1, thresholds }) {
  return evaluatePairWithConditions({
    pair,
    uniqueWalletsH1,
    context: { thresholds },
    conditions: DEFAULT_CONDITIONS
  });
}

export function evaluatePairWithConditions({ pair, uniqueWalletsH1, context = {}, conditions = [] }) {
  const thresholds = resolveThresholds(context);
  const effectiveConditions = conditions.length > 0 ? conditions : DEFAULT_CONDITIONS;
  const metricContext = buildMetricContext({ pair, uniqueWalletsH1, context });
  metricContext.thresholds = thresholds;
  const checks = {};
  const details = [];

  for (const condition of effectiveConditions) {
    const detail = evaluateCondition(condition, metricContext);
    checks[condition.id ?? condition.metric] = detail.passed;
    details.push(detail);
  }

  return {
    shouldAlert: details.every((detail) => detail.passed),
    checks,
    details,
    reasons: details.filter((detail) => !detail.passed).map(formatFailedCondition)
  };
}

export function buildAlert({ pair, uniqueWalletsH1, evaluation, target }) {
  return {
    targetLabel: target.label ?? null,
    chainId: pair.chainId,
    dexId: pair.dexId,
    pairAddress: pair.pairAddress,
    tokenAddress: pair.baseToken?.address ?? null,
    symbol: pair.symbol,
    priceUsd: pair.priceUsd,
    volumeH1Usd: pair.volumeH1Usd,
    marketCapUsd: pair.marketCapUsd,
    fdvUsd: pair.fdvUsd,
    liquidityUsd: pair.liquidityUsd,
    uniqueWalletsH1,
    checks: evaluation.checks,
    conditionDetails: evaluation.details,
    url: pair.url,
    observedAt: new Date().toISOString()
  };
}

function buildReasons({ pair, uniqueWalletsH1, thresholds, checks }) {
  const reasons = [];

  if (!checks.volume) {
    reasons.push(`volume.h1 ${format(pair.volumeH1Usd)} <= ${thresholds.minVolumeH1Usd}`);
  }

  if (!checks.marketCap) {
    reasons.push(`marketCap ${format(pair.marketCapUsd)} >= ${thresholds.maxMarketCapUsd} or missing`);
  }

  if (!checks.uniqueWallets) {
    reasons.push(`uniqueWalletsH1 ${uniqueWalletsH1} <= ${thresholds.minUniqueWalletsH1}`);
  }

  return reasons;
}

function format(value) {
  return value === null || value === undefined ? "missing" : String(value);
}

function buildMetricContext({ pair, uniqueWalletsH1, context }) {
  return {
    pair,
    uniqueWalletsH1,
    volumeH1Usd: pair.volumeH1Usd,
    marketCapUsd: pair.marketCapUsd,
    fdvUsd: pair.fdvUsd,
    liquidityUsd: pair.liquidityUsd,
    priceUsd: pair.priceUsd,
    thresholds: context.thresholds ?? {},
    chain: context.chain ?? {},
    target: context.target ?? {},
    walletStats: context.walletStats ?? {}
  };
}

export function resolveThresholds(context = {}) {
  return {
    ...(context.thresholds ?? {}),
    ...(context.chain?.thresholds ?? {}),
    ...(context.target?.thresholds ?? {})
  };
}

export function resolveConditions({ config = {}, chain = {}, target = {} }) {
  if (Array.isArray(target.conditions) && target.conditions.length > 0) {
    return target.conditions;
  }

  if (Array.isArray(chain.conditions) && chain.conditions.length > 0) {
    return chain.conditions;
  }

  return Array.isArray(config.conditions) ? config.conditions : [];
}

function evaluateCondition(condition, metricContext) {
  const actual = getByPath(metricContext, condition.metric);
  const expected = condition.valueFrom ? getByPath(metricContext, condition.valueFrom) : condition.value;
  const operator = condition.operator ?? ">";
  const passed = compareValues(actual, operator, expected);

  return {
    id: condition.id ?? condition.metric,
    label: condition.label ?? condition.id ?? condition.metric,
    metric: condition.metric,
    operator,
    expected,
    actual,
    passed
  };
}

function compareValues(actual, operator, expected) {
  if (operator === "exists") {
    return actual !== null && actual !== undefined;
  }

  if (actual === null || actual === undefined || expected === null || expected === undefined) {
    return false;
  }

  switch (operator) {
    case ">":
      return Number(actual) > Number(expected);
    case ">=":
      return Number(actual) >= Number(expected);
    case "<":
      return Number(actual) < Number(expected);
    case "<=":
      return Number(actual) <= Number(expected);
    case "==":
      return actual === expected;
    case "!=":
      return actual !== expected;
    default:
      throw new Error(`Unsupported condition operator: ${operator}`);
  }
}

function formatFailedCondition(detail) {
  return `${detail.label} ${format(detail.actual)} ${detail.operator} ${format(detail.expected)} not satisfied`;
}

function getByPath(source, keyPath) {
  return String(keyPath)
    .split(".")
    .filter(Boolean)
    .reduce((value, key) => (value === null || value === undefined ? undefined : value[key]), source);
}
