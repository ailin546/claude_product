export class SolanaRpcClient {
  constructor({ url, fetchImpl = fetch, timeoutMs = 30_000, batchSize = 20 }) {
    if (!url) {
      throw new Error("Solana RPC url is required");
    }
    this.url = url;
    this.fetchImpl = fetchImpl;
    this.timeoutMs = timeoutMs;
    this.batchSize = batchSize;
    this.nextId = 1;
  }

  async request(method, params = []) {
    const [result] = await this.batch([{ method, params }]);
    return result;
  }

  async batch(calls) {
    const results = [];

    for (let index = 0; index < calls.length; index += this.batchSize) {
      const chunk = calls.slice(index, index + this.batchSize);
      const payload = chunk.map((call) => ({
        jsonrpc: "2.0",
        id: this.nextId++,
        method: call.method,
        params: call.params ?? []
      }));
      const response = await this.#post(payload.length === 1 ? payload[0] : payload);
      const responses = Array.isArray(response) ? response : [response];
      const byId = new Map(responses.map((item) => [item.id, item]));

      for (const request of payload) {
        const item = byId.get(request.id);
        if (!item) {
          throw new Error(`Solana RPC response missing id ${request.id}`);
        }
        if (item.error) {
          throw new Error(`Solana RPC ${request.method} failed: ${item.error.message ?? JSON.stringify(item.error)}`);
        }
        results.push(item.result);
      }
    }

    return results;
  }

  async #post(payload) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(this.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      if (!response.ok) {
        const text = await response.text().catch(() => "");
        throw new Error(`Solana RPC HTTP ${response.status}: ${text.slice(0, 300)}`);
      }

      return response.json();
    } finally {
      clearTimeout(timeout);
    }
  }
}

export async function countUniqueSolanaWallets({
  rpc,
  pairAddress,
  lookbackSeconds = 3600,
  signaturePageLimit = 1000,
  maxSignatures = 2000,
  transactionBatchSize = 20
}) {
  const cutoffSeconds = Math.floor(Date.now() / 1000) - lookbackSeconds;
  const signatures = await collectRecentSignatures({
    rpc,
    address: pairAddress,
    cutoffSeconds,
    signaturePageLimit,
    maxSignatures
  });
  const transactions = await fetchTransactions({
    rpc,
    signatures: signatures.map((item) => item.signature),
    transactionBatchSize
  });
  const wallets = new Set(transactions.map(extractFeePayer).filter(Boolean));

  return {
    uniqueWallets: wallets.size,
    swapLogs: signatures.length,
    swapTransactions: signatures.length,
    fromBlock: null,
    toBlock: null,
    fromTimestamp: cutoffSeconds,
    toTimestamp: Math.floor(Date.now() / 1000),
    scannedSignatures: signatures.length
  };
}

export async function collectRecentSignatures({
  rpc,
  address,
  cutoffSeconds,
  signaturePageLimit = 1000,
  maxSignatures = 2000
}) {
  const signatures = [];
  const seen = new Set();
  let before;

  while (signatures.length < maxSignatures) {
    const page = await rpc.request("getSignaturesForAddress", [
      address,
      {
        limit: Math.min(signaturePageLimit, maxSignatures - signatures.length),
        ...(before ? { before } : {})
      }
    ]);

    if (!Array.isArray(page) || page.length === 0) {
      break;
    }

    let added = 0;
    for (const item of page) {
      if (!item?.signature) continue;
      if (Number.isFinite(item.blockTime) && item.blockTime < cutoffSeconds) {
        return signatures;
      }
      if (seen.has(item.signature)) {
        continue;
      }
      seen.add(item.signature);
      signatures.push(item);
      added += 1;
      if (signatures.length >= maxSignatures) {
        return signatures;
      }
    }

    before = page.at(-1)?.signature;
    if (!before || added === 0) {
      break;
    }
  }

  return signatures;
}

async function fetchTransactions({ rpc, signatures, transactionBatchSize }) {
  const transactions = [];

  for (let index = 0; index < signatures.length; index += transactionBatchSize) {
    const chunk = signatures.slice(index, index + transactionBatchSize);
    const results = await rpc.batch(chunk.map((signature) => ({
      method: "getTransaction",
      params: [
        signature,
        {
          encoding: "json",
          maxSupportedTransactionVersion: 0
        }
      ]
    })));
    transactions.push(...results.filter(Boolean));
  }

  return transactions;
}

function extractFeePayer(transaction) {
  const accountKeys = transaction?.transaction?.message?.accountKeys;
  const firstKey = Array.isArray(accountKeys) ? accountKeys[0] : null;

  if (typeof firstKey === "string") {
    return firstKey;
  }

  if (firstKey && typeof firstKey.pubkey === "string") {
    return firstKey.pubkey;
  }

  return null;
}
