export class JsonRpcClient {
  constructor({ url, fetchImpl = fetch, timeoutMs = 30_000, batchSize = 100 }) {
    if (!url) {
      throw new Error("RPC url is required");
    }
    this.url = url;
    this.fetchImpl = fetchImpl;
    this.timeoutMs = timeoutMs;
    this.batchSize = batchSize;
    this.nextId = 1;
  }

  async request(method, params = []) {
    const [result] = await this.batch([{ method, params }]);
    return result;
  }

  async batch(calls) {
    const results = [];
    for (let index = 0; index < calls.length; index += this.batchSize) {
      const chunk = calls.slice(index, index + this.batchSize);
      const payload = chunk.map((call) => ({
        jsonrpc: "2.0",
        id: this.nextId++,
        method: call.method,
        params: call.params ?? []
      }));

      const response = await this.#post(payload.length === 1 ? payload[0] : payload);
      const responses = Array.isArray(response) ? response : [response];
      const byId = new Map(responses.map((item) => [item.id, item]));

      for (const request of payload) {
        const item = byId.get(request.id);
        if (!item) {
          throw new Error(`RPC response missing id ${request.id}`);
        }
        if (item.error) {
          throw new Error(`RPC ${request.method} failed: ${item.error.message ?? JSON.stringify(item.error)}`);
        }
        results.push(item.result);
      }
    }
    return results;
  }

  async #post(payload) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(this.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      if (!response.ok) {
        const text = await response.text().catch(() => "");
        throw new Error(`RPC HTTP ${response.status}: ${text.slice(0, 300)}`);
      }

      return response.json();
    } finally {
      clearTimeout(timeout);
    }
  }
}

export function toHex(number) {
  if (!Number.isSafeInteger(number) || number < 0) {
    throw new Error(`Cannot convert invalid block number to hex: ${number}`);
  }
  return `0x${number.toString(16)}`;
}

export function fromHex(hex) {
  if (typeof hex !== "string") {
    throw new Error(`Expected hex string, received ${typeof hex}`);
  }
  return Number.parseInt(hex, 16);
}
