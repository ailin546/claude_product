import { fromHex, toHex } from "./rpc.js";

export const SWAP_TOPICS = [
  // Uniswap V2 style: Swap(address,uint256,uint256,uint256,uint256,address)
  "0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822",
  // Uniswap V3 style: Swap(address,address,int256,int256,uint160,uint128,int24)
  "0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67"
];

export async function countUniqueSwapWallets({ rpc, pairAddress, lookbackSeconds = 3600, logChunkSize = 2000 }) {
  const latestBlockNumber = fromHex(await rpc.request("eth_blockNumber"));
  const latestBlock = await getBlock(rpc, latestBlockNumber);
  const targetTimestamp = latestBlock.timestamp - lookbackSeconds;
  const fromBlock = await findFirstBlockAtOrAfter(rpc, targetTimestamp, 0, latestBlockNumber);
  const logs = await getSwapLogsChunked({
    rpc,
    pairAddress,
    fromBlock,
    toBlock: latestBlockNumber,
    logChunkSize
  });

  const txHashes = [...new Set(logs.map((log) => log.transactionHash).filter(Boolean))];
  const transactions = await rpc.batch(txHashes.map((hash) => ({
    method: "eth_getTransactionByHash",
    params: [hash]
  })));
  const wallets = new Set(transactions.map((tx) => normalizeAddress(tx?.from)).filter(Boolean));

  return {
    uniqueWallets: wallets.size,
    swapLogs: logs.length,
    swapTransactions: txHashes.length,
    fromBlock,
    toBlock: latestBlockNumber,
    fromTimestamp: targetTimestamp,
    toTimestamp: latestBlock.timestamp
  };
}

export async function findFirstBlockAtOrAfter(rpc, timestamp, low, high) {
  let left = low;
  let right = high;
  let answer = high;

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const block = await getBlock(rpc, mid);
    if (block.timestamp >= timestamp) {
      answer = mid;
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }

  return answer;
}

export async function getSwapLogsChunked({ rpc, pairAddress, fromBlock, toBlock, logChunkSize }) {
  const logs = [];
  for (let start = fromBlock; start <= toBlock; start += logChunkSize) {
    const end = Math.min(start + logChunkSize - 1, toBlock);
    const chunkLogs = await rpc.request("eth_getLogs", [{
      address: pairAddress,
      fromBlock: toHex(start),
      toBlock: toHex(end),
      topics: [SWAP_TOPICS]
    }]);
    logs.push(...chunkLogs);
  }
  return logs;
}

async function getBlock(rpc, blockNumber) {
  const block = await rpc.request("eth_getBlockByNumber", [toHex(blockNumber), false]);
  if (!block) {
    throw new Error(`Block ${blockNumber} not found`);
  }

  return {
    number: fromHex(block.number),
    timestamp: fromHex(block.timestamp)
  };
}

function normalizeAddress(address) {
  return typeof address === "string" ? address.toLowerCase() : null;
}
