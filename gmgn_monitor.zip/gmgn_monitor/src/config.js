import { readFile } from "node:fs/promises";
import path from "node:path";

const DEFAULTS = {
  monitor: {
    intervalSeconds: 300,
    lookbackSeconds: 3600,
    alertCooldownSeconds: 3600,
    rpcBatchSize: 100,
    maxPairsPerToken: 3,
    dryRun: false
  },
  thresholds: {
    minVolumeH1Usd: 2_000_000,
    maxMarketCapUsd: 10_000_000,
    minUniqueWalletsH1: 1_000
  },
  chains: {},
  chainAliases: {
    eth: "ethereum",
    sol: "solana"
  },
  targets: [],
  gmgn: {
    apiKey: "${GMGN_API_KEY}",
    cliCommand: "gmgn-cli"
  },
  discovery: {
    gmgnTrending: {
      enabled: true,
      chains: ["ethereum", "bsc", "solana"],
      interval: "1h",
      orderBy: "volume",
      direction: "desc",
      limit: 50,
      filters: [],
      timeoutMs: 30_000
    },
    latestBoosted: {
      enabled: false,
      chains: [],
      limit: 20
    }
  },
  conditions: [],
  actions: {
    trade: {
      enabled: false,
      mode: "dry-run",
      command: "",
      args: [],
      passAlertJsonOnStdin: true,
      timeoutMs: 30_000,
      logDryRun: true
    }
  },
  notifiers: {
    console: {
      enabled: true
    },
    telegram: {
      enabled: false,
      botToken: "",
      chatId: "",
      parseMode: "",
      messageThreadId: null,
      disableWebPagePreview: true
    },
    webhook: {
      enabled: false,
      url: "",
      method: "POST",
      headers: {
        "content-type": "application/json"
      }
    }
  }
};

export async function loadConfig(configPath) {
  const absolutePath = path.resolve(configPath);
  await loadDotEnv(path.dirname(absolutePath));
  const raw = await readFile(absolutePath, "utf8");
  const parsed = JSON.parse(raw);
  const config = mergeDeep(DEFAULTS, parsed);
  const resolved = resolveEnv(config);
  validateConfig(resolved);
  return resolved;
}

export async function loadDotEnv(cwd = process.cwd()) {
  const envPath = path.resolve(cwd, ".env");
  let raw;

  try {
    raw = await readFile(envPath, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") {
      return;
    }
    throw error;
  }

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const equalIndex = trimmed.indexOf("=");
    if (equalIndex <= 0) continue;
    const key = trimmed.slice(0, equalIndex).trim();
    const value = unquoteEnvValue(trimmed.slice(equalIndex + 1).trim());
    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

export function applyOverrides(config, overrides = []) {
  const result = cloneValue(config);

  for (const override of overrides) {
    const { keyPath, value } = parseOverride(override);
    setByPath(result, keyPath, value);
  }

  validateConfig(result);
  return result;
}

export function mergeDeep(base, override) {
  if (Array.isArray(base) || Array.isArray(override)) {
    return cloneValue(override === undefined ? base : override);
  }

  if (!isPlainObject(base) || !isPlainObject(override)) {
    return cloneValue(override === undefined ? base : override);
  }

  const result = cloneValue(base);
  for (const [key, value] of Object.entries(override)) {
    result[key] = mergeDeep(base[key], value);
  }
  return result;
}

export function resolveEnv(value) {
  if (typeof value === "string") {
    return value.replace(/\$\{([A-Z0-9_]+)(?::-(.*?))?\}/gi, (_, name, fallback) => {
      const envValue = process.env[name];
      return envValue === undefined || envValue === "" ? fallback ?? "" : envValue;
    });
  }

  if (Array.isArray(value)) {
    return value.map((item) => resolveEnv(item));
  }

  if (isPlainObject(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, resolveEnv(item)]));
  }

  return value;
}

export function validateConfig(config) {
  const errors = [];

  if (!Number.isFinite(config.monitor.intervalSeconds) || config.monitor.intervalSeconds <= 0) {
    errors.push("monitor.intervalSeconds must be a positive number");
  }

  if (!Number.isFinite(config.monitor.lookbackSeconds) || config.monitor.lookbackSeconds <= 0) {
    errors.push("monitor.lookbackSeconds must be a positive number");
  }

  if (!Array.isArray(config.targets)) {
    errors.push("targets must be an array");
  } else {
    config.targets.forEach((target, index) => {
      if (!target.chainId) {
        errors.push(`targets[${index}].chainId is required`);
      }
      if (!target.tokenAddress && !target.pairAddress) {
        errors.push(`targets[${index}] must contain tokenAddress or pairAddress`);
      }
    });
  }

  if (!Array.isArray(config.conditions)) {
    errors.push("conditions must be an array");
  }

  if (config.notifiers?.telegram?.enabled) {
    if (!config.notifiers.telegram.botToken) {
      errors.push("notifiers.telegram.botToken is required when Telegram notifier is enabled");
    }
    if (!config.notifiers.telegram.chatId) {
      errors.push("notifiers.telegram.chatId is required when Telegram notifier is enabled");
    }
  }

  if (config.actions?.trade?.enabled) {
    if (!["dry-run", "live"].includes(config.actions.trade.mode)) {
      errors.push("actions.trade.mode must be dry-run or live");
    }
    if (config.actions.trade.mode === "live" && !config.actions.trade.command) {
      errors.push("actions.trade.command is required when actions.trade.mode is live");
    }
    if (!Array.isArray(config.actions.trade.args)) {
      errors.push("actions.trade.args must be an array");
    }
  }

  if (errors.length > 0) {
    throw new Error(`Invalid config:\n- ${errors.join("\n- ")}`);
  }
}

function parseOverride(override) {
  const equalIndex = override.indexOf("=");
  if (equalIndex <= 0) {
    throw new Error(`Invalid --set override "${override}". Expected key.path=value`);
  }

  return {
    keyPath: override.slice(0, equalIndex).split(".").filter(Boolean),
    value: parseOverrideValue(override.slice(equalIndex + 1))
  };
}

function parseOverrideValue(value) {
  if (value === "true") return true;
  if (value === "false") return false;
  if (value === "null") return null;

  const number = Number(value);
  if (value.trim() !== "" && Number.isFinite(number)) {
    return number;
  }

  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

function setByPath(target, keyPath, value) {
  if (keyPath.length === 0) {
    throw new Error("Override key path cannot be empty");
  }

  let cursor = target;
  for (const key of keyPath.slice(0, -1)) {
    if (!isPlainObject(cursor[key])) {
      cursor[key] = {};
    }
    cursor = cursor[key];
  }

  cursor[keyPath.at(-1)] = value;
}

function unquoteEnvValue(value) {
  if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
    return value.slice(1, -1);
  }
  return value;
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && value.constructor === Object;
}

function cloneValue(value) {
  if (Array.isArray(value)) {
    return value.map((item) => cloneValue(item));
  }

  if (isPlainObject(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneValue(item)]));
  }

  return value;
}
