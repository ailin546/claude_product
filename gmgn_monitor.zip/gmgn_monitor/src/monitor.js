import { DexScreenerClient, normalizePair, sortPairsByH1Volume } from "./dexscreener.js";
import { countUniqueSwapWallets } from "./evm.js";
import { evaluatePairWithConditions, buildAlert, resolveConditions } from "./evaluator.js";
import { notify } from "./notifier.js";
import { JsonRpcClient } from "./rpc.js";
import { runActions } from "./actions.js";
import { countUniqueSolanaWallets, SolanaRpcClient } from "./solana.js";
import { discoverGmgnTrendingPairs } from "./gmgn.js";

export class TokenMonitor {
  constructor({
    config,
    dexClient = new DexScreenerClient(),
    rpcFactory = defaultRpcFactory,
    notifyFn = notify,
    actionFn = runActions
  }) {
    this.config = config;
    this.dexClient = dexClient;
    this.rpcFactory = rpcFactory;
    this.notifyFn = notifyFn;
    this.actionFn = actionFn;
    this.lastAlertAtByPair = new Map();
  }

  async runOnce() {
    const gmgnPairs = await discoverGmgnTrendingPairs({ config: this.config });
    const targets = await this.#buildTargets();
    const results = [];

    for (const pair of gmgnPairs) {
      const target = {
        label: `gmgn:${pair.chainId}:${pair.symbol}`,
        enabled: true,
        chainId: pair.chainId,
        tokenAddress: pair.baseToken?.address ?? "",
        pairAddress: pair.pairAddress,
        source: "gmgnTrending"
      };
      const result = await this.#checkPair(target, pair);
      results.push(result);
    }

    for (const target of targets) {
      const pairs = await this.#resolvePairs(target);

      if (pairs.length === 0) {
        results.push(skippedTarget(target, "no pairs resolved; check tokenAddress or pairAddress"));
        continue;
      }

      for (const pair of pairs) {
        const result = await this.#checkPair(target, pair);
        results.push(result);
      }
    }

    return results;
  }

  async #buildTargets() {
    const directTargets = this.config.targets
      .filter((target) => target.enabled !== false)
      .map((target) => this.#normalizeTarget(target));
    const latestBoosted = this.config.discovery?.latestBoosted;

    if (!latestBoosted?.enabled) {
      return directTargets;
    }

    const allowedChains = new Set(latestBoosted.chains ?? []);
    const boosted = await this.dexClient.getLatestBoostedTokens();
    const discovered = boosted
      .filter((item) => item.chainId && item.tokenAddress)
      .filter((item) => allowedChains.size === 0 || allowedChains.has(item.chainId))
      .slice(0, latestBoosted.limit ?? 20)
      .map((item) => ({
        label: `boosted:${item.chainId}:${item.tokenAddress}`,
        chainId: this.#normalizeChainId(item.chainId),
        tokenAddress: item.tokenAddress
      }));

    return dedupeTargets([...directTargets, ...discovered]);
  }

  async #resolvePairs(target) {
    if (target.pairAddress) {
      const pair = normalizePair(await this.dexClient.getPair(target.chainId, target.pairAddress));
      return pair ? [pair] : [];
    }

    const rawPairs = await this.dexClient.getTokenPairs(target.chainId, target.tokenAddress);
    return sortPairsByH1Volume(rawPairs)
      .slice(0, this.config.monitor.maxPairsPerToken)
      .map((pair) => normalizePair(pair))
      .filter(Boolean);
  }

  async #checkPair(target, pair) {
    const normalizedPair = {
      ...pair,
      chainId: this.#normalizeChainId(pair.chainId)
    };
    const chain = this.config.chains[normalizedPair.chainId];

    if (!chain) {
      return skipped(normalizedPair, target, `missing chain config for ${normalizedPair.chainId}`);
    }

    if (!chain.rpcUrl) {
      return skipped(normalizedPair, target, `missing rpcUrl for ${normalizedPair.chainId}`);
    }

    if (!["evm", "solana"].includes(chain.kind)) {
      return skipped(normalizedPair, target, `chain kind ${chain.kind} is not supported for wallet counting`);
    }

    const walletStats = normalizedPair.source === "gmgnTrending"
      ? this.#walletStatsFromGmgn(normalizedPair)
      : await this.#countWallets({ chain, pair: normalizedPair });
    const evaluation = evaluatePairWithConditions({
      pair: normalizedPair,
      uniqueWalletsH1: walletStats.uniqueWallets,
      context: {
        thresholds: this.config.thresholds,
        chain,
        target,
        walletStats
      },
      conditions: resolveConditions({ config: this.config, chain, target })
    });
    const alert = buildAlert({
      pair: normalizedPair,
      uniqueWalletsH1: walletStats.uniqueWallets,
      evaluation,
      target
    });

    const isSuppressed = evaluation.shouldAlert && this.#isAlertSuppressed(pair);
    const result = {
      status: evaluation.shouldAlert ? (isSuppressed ? "suppressed" : "alert") : "ok",
      target,
      pair: normalizedPair,
      walletStats,
      evaluation,
      alert
    };

    if (evaluation.shouldAlert && !isSuppressed) {
      await this.notifyFn(alert, this.config);
      await this.actionFn(alert, this.config);
      this.#rememberAlert(pair);
    }

    return result;
  }

  #isAlertSuppressed(pair) {
    const cooldownMs = (this.config.monitor.alertCooldownSeconds ?? 0) * 1000;
    if (cooldownMs <= 0) {
      return false;
    }

    const key = pairKey(pair);
    const lastAlertAt = this.lastAlertAtByPair.get(key);
    return lastAlertAt !== undefined && Date.now() - lastAlertAt < cooldownMs;
  }

  #rememberAlert(pair) {
    this.lastAlertAtByPair.set(pairKey(pair), Date.now());
  }

  async #countWallets({ chain, pair }) {
    if (chain.kind === "evm") {
      const rpc = this.rpcFactory(chain, this.config);
      return countUniqueSwapWallets({
        rpc,
        pairAddress: pair.pairAddress,
        lookbackSeconds: this.config.monitor.lookbackSeconds,
        logChunkSize: chain.logChunkSize ?? 2000
      });
    }

    if (chain.kind === "solana") {
      const rpc = this.rpcFactory(chain, this.config);
      return countUniqueSolanaWallets({
        rpc,
        pairAddress: pair.pairAddress,
        lookbackSeconds: this.config.monitor.lookbackSeconds,
        signaturePageLimit: chain.signaturePageLimit ?? 1000,
        maxSignatures: chain.maxSignatures ?? 2000,
        transactionBatchSize: chain.transactionBatchSize ?? 20
      });
    }

    throw new Error(`Unsupported chain kind: ${chain.kind}`);
  }

  #walletStatsFromGmgn(pair) {
    const wallets = pair.holderCount ?? 0;
    return {
      uniqueWallets: wallets,
      swapLogs: pair.swapsH1 ?? 0,
      swapTransactions: pair.swapsH1 ?? 0,
      fromBlock: null,
      toBlock: null,
      fromTimestamp: null,
      toTimestamp: null,
      source: "gmgn.holder_count"
    };
  }

  #normalizeTarget(target) {
    return {
      ...target,
      chainId: this.#normalizeChainId(target.chainId)
    };
  }

  #normalizeChainId(chainId) {
    return this.config.chainAliases?.[chainId] ?? chainId;
  }
}

function defaultRpcFactory(chain, config) {
  if (chain.kind === "solana") {
    return new SolanaRpcClient({
      url: chain.rpcUrl,
      batchSize: chain.transactionBatchSize ?? config.monitor.rpcBatchSize
    });
  }

  return new JsonRpcClient({
    url: chain.rpcUrl,
    batchSize: config.monitor.rpcBatchSize
  });
}

function skipped(pair, target, reason) {
  return {
    status: "skipped",
    target,
    pair,
    reason
  };
}

function skippedTarget(target, reason) {
  return {
    status: "skipped",
    target,
    pair: null,
    reason
  };
}

function dedupeTargets(targets) {
  const seen = new Set();
  const result = [];

  for (const target of targets) {
    const key = `${target.chainId}:${target.tokenAddress ?? ""}:${target.pairAddress ?? ""}`.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      result.push(target);
    }
  }

  return result;
}

function pairKey(pair) {
  return `${pair.chainId}:${pair.pairAddress}`.toLowerCase();
}
