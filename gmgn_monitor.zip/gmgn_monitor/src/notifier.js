export async function notify(alert, config, { fetchImpl = fetch } = {}) {
  const tasks = [];
  const dryRun = Boolean(config.monitor?.dryRun);

  if (config.notifiers?.console?.enabled !== false) {
    tasks.push(notifyConsole(alert, dryRun));
  }

  if (config.notifiers?.webhook?.enabled && !dryRun) {
    tasks.push(notifyWebhook(alert, config.notifiers.webhook, { fetchImpl }));
  }

  if (config.notifiers?.telegram?.enabled && !dryRun) {
    tasks.push(notifyTelegram(alert, config.notifiers.telegram, { fetchImpl }));
  }

  await Promise.all(tasks);
}

export async function notifyConsole(alert, dryRun = false) {
  const prefix = dryRun ? "[DRY-RUN ALERT]" : "[ALERT]";
  console.log(`${prefix} ${alert.symbol} ${alert.chainId}:${alert.pairAddress}`);
  console.log(`  volumeH1Usd=${alert.volumeH1Usd} marketCapUsd=${alert.marketCapUsd} uniqueWalletsH1=${alert.uniqueWalletsH1}`);
  if (alert.url) {
    console.log(`  ${alert.url}`);
  }
}

export async function notifyWebhook(alert, webhook, { fetchImpl = fetch } = {}) {
  if (!webhook.url) {
    throw new Error("Webhook notifier is enabled but url is empty");
  }

  const response = await fetchImpl(webhook.url, {
    method: webhook.method ?? "POST",
    headers: webhook.headers ?? { "content-type": "application/json" },
    body: JSON.stringify({
      type: "token-watch.alert",
      alert
    })
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Webhook request failed (${response.status}): ${text.slice(0, 300)}`);
  }
}

export async function notifyTelegram(alert, telegram, { fetchImpl = fetch } = {}) {
  if (!telegram.botToken) {
    throw new Error("Telegram notifier is enabled but botToken is empty");
  }
  if (!telegram.chatId) {
    throw new Error("Telegram notifier is enabled but chatId is empty");
  }

  const body = {
    chat_id: telegram.chatId,
    text: formatTelegramMessage(alert),
    disable_web_page_preview: telegram.disableWebPagePreview !== false
  };

  if (telegram.parseMode) {
    body.parse_mode = telegram.parseMode;
  }

  if (telegram.messageThreadId !== null && telegram.messageThreadId !== undefined) {
    body.message_thread_id = telegram.messageThreadId;
  }

  const response = await fetchImpl(`https://api.telegram.org/bot${telegram.botToken}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Telegram request failed (${response.status}): ${text.slice(0, 300)}`);
  }
}

export function formatTelegramMessage(alert) {
  const lines = [
    "Token monitor alert",
    `${alert.symbol} on ${alert.chainId}`,
    `Pair: ${alert.pairAddress}`,
    `Token: ${alert.tokenAddress ?? "-"}`,
    `1h volume: ${formatUsd(alert.volumeH1Usd)}`,
    `Market cap: ${formatUsd(alert.marketCapUsd)}`,
    `1h unique wallets: ${formatNumber(alert.uniqueWalletsH1)}`,
    `Liquidity: ${formatUsd(alert.liquidityUsd)}`
  ];

  if (alert.url) {
    lines.push(alert.url);
  }

  return lines.join("\n");
}

function formatUsd(value) {
  return value === null || value === undefined ? "-" : `$${formatNumber(value)}`;
}

function formatNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toLocaleString("en-US", { maximumFractionDigits: 6 }) : "-";
}
