#!/usr/bin/env node

import { applyOverrides, loadConfig } from "./config.js";
import { TokenMonitor } from "./monitor.js";

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.help) {
    printHelp();
    return;
  }

  const configPath = args.config ?? "config.json";
  let config = await loadConfig(configPath);
  config = applyOverrides(config, args.set ?? []);

  if (args.once !== undefined) {
    config.monitor.runOnce = Boolean(args.once);
  }

  if (args.dryRun !== undefined) {
    config.monitor.dryRun = Boolean(args.dryRun);
  }

  const monitor = new TokenMonitor({ config });

  if (args.once) {
    const results = await monitor.runOnce();
    printSummary(results);
    return;
  }

  console.log(`token-watch started; interval=${config.monitor.intervalSeconds}s`);
  await runForever(monitor, config.monitor.intervalSeconds);
}

function parseArgs(argv) {
  const args = {};

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];

    if (arg === "--help" || arg === "-h") {
      args.help = true;
    } else if (arg === "--config" || arg === "-c") {
      const configPath = argv[++index];
      if (!configPath || configPath.startsWith("-")) {
        throw new Error(`${arg} requires a config file path`);
      }
      args.config = configPath;
    } else if (arg === "--once") {
      args.once = true;
    } else if (arg === "--dry-run") {
      args.dryRun = true;
    } else if (arg === "--no-dry-run") {
      args.dryRun = false;
    } else if (arg === "--set") {
      const override = argv[++index];
      if (!override || override.startsWith("-")) {
        throw new Error(`${arg} requires key.path=value`);
      }
      args.set ??= [];
      args.set.push(override);
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return args;
}

async function runForever(monitor, intervalSeconds) {
  while (true) {
    try {
      const results = await monitor.runOnce();
      printSummary(results);
    } catch (error) {
      console.error(`[ERROR] ${error.stack ?? error.message}`);
    }

    await sleep(intervalSeconds * 1000);
  }
}

function printSummary(results) {
  const counts = results.reduce((acc, result) => {
    acc[result.status] = (acc[result.status] ?? 0) + 1;
    return acc;
  }, {});

  console.log(`[SUMMARY] checked=${results.length} alert=${counts.alert ?? 0} suppressed=${counts.suppressed ?? 0} ok=${counts.ok ?? 0} skipped=${counts.skipped ?? 0}`);

  for (const result of results) {
    if (result.status === "skipped") {
      console.log(`[SKIP] ${result.pair?.symbol ?? result.target.label ?? "target"}: ${result.reason}`);
      continue;
    }

    const pair = result.pair;
    const stats = result.walletStats;
    const reasons = result.evaluation.reasons.length > 0 ? `; ${result.evaluation.reasons.join("; ")}` : "";
    const cooldown = result.status === "suppressed" ? " alertCooldown=active" : "";
    console.log(`[${result.status.toUpperCase()}] ${pair.symbol} ${pair.chainId}:${pair.pairAddress} volumeH1=${pair.volumeH1Usd} marketCap=${pair.marketCapUsd} wallets=${stats.uniqueWallets}${cooldown}${reasons}`);
  }
}

function printHelp() {
  console.log(`
Usage:
  node src/index.js --config config.json --once
  node src/index.js --config config.json

Options:
  -c, --config <path>   Config file path. Default: config.json
  --once               Run one check and exit.
  --dry-run            Print alerts but keep dry-run flag in payload context.
  --no-dry-run         Disable dry-run flag.
  --set <key=value>    Override a config value, for example thresholds.minVolumeH1Usd=3000000.
  -h, --help           Show this help.
`);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

main().catch((error) => {
  console.error(error.stack ?? error.message);
  process.exitCode = 1;
});
