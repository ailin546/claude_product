#!/usr/bin/env node

import { createServer } from "node:http";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadConfig } from "./config.js";
import { TokenMonitor } from "./monitor.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.resolve(__dirname, "../public");
const MAX_EVENTS = 200;

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const configPath = path.resolve(args.config ?? "config.json");
  const logFile = path.resolve(args.logFile ?? "logs/web.log");
  const state = createState({ configPath, logFile });
  await reloadConfig(state);

  const server = createServer((request, response) => {
    handleRequest(request, response, state).catch((error) => {
      sendJson(response, 500, { error: error.message });
    });
  });

  const port = Number(args.port ?? process.env.PORT ?? 8787);
  server.on("error", (error) => {
    log(state, "server.error", { message: error.message, code: error.code });
  });
  server.listen(port, args.host ?? "127.0.0.1", () => {
    const message = `token-watch web listening at http://${args.host ?? "127.0.0.1"}:${port}`;
    console.log(message);
    log(state, "server.started", { host: args.host ?? "127.0.0.1", port, configPath });
  });

  for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => {
      log(state, "server.stopping", { signal }).finally(() => process.exit(0));
    });
  }

  process.on("uncaughtException", (error) => {
    log(state, "process.uncaughtException", { message: error.stack ?? error.message }).finally(() => process.exit(1));
  });

  process.on("unhandledRejection", (reason) => {
    log(state, "process.unhandledRejection", { message: reason?.stack ?? String(reason) });
  });
}

function createState({ configPath, logFile }) {
  return {
    configPath,
    logFile,
    configRaw: "",
    config: null,
    monitor: null,
    running: false,
    timer: null,
    currentRun: null,
    lastRunAt: null,
    lastError: null,
    events: []
  };
}

async function handleRequest(request, response, state) {
  const url = new URL(request.url, "http://localhost");

  if (url.pathname === "/api/status" && request.method === "GET") {
    return sendJson(response, 200, serializeStatus(state));
  }

  if (url.pathname === "/api/config" && request.method === "GET") {
    return sendJson(response, 200, {
      path: state.configPath,
      raw: state.configRaw,
      parsed: sanitizeConfig(state.config)
    });
  }

  if (url.pathname === "/api/config" && request.method === "PUT") {
    const body = await readJson(request);
    await saveConfig(state, body.raw);
    return sendJson(response, 200, {
      ok: true,
      status: serializeStatus(state)
    });
  }

  if (url.pathname === "/api/run-once" && request.method === "POST") {
    const results = await runOnce(state, { source: "manual" });
    return sendJson(response, 200, { ok: true, results, status: serializeStatus(state) });
  }

  if (url.pathname === "/api/start" && request.method === "POST") {
    startMonitor(state);
    return sendJson(response, 200, { ok: true, status: serializeStatus(state) });
  }

  if (url.pathname === "/api/stop" && request.method === "POST") {
    stopMonitor(state);
    return sendJson(response, 200, { ok: true, status: serializeStatus(state) });
  }

  if (url.pathname === "/api/events" && request.method === "GET") {
    return sendJson(response, 200, { events: state.events });
  }

  if (url.pathname.startsWith("/api/")) {
    return sendJson(response, 404, { error: "Not found" });
  }

  return serveStatic(request, response, url.pathname);
}

async function reloadConfig(state) {
  state.configRaw = await readFile(state.configPath, "utf8");
  state.config = await loadConfig(state.configPath);
  state.monitor = createMonitor(state);
}

async function saveConfig(state, raw) {
  JSON.parse(raw);
  const wasRunning = state.running;
  stopMonitor(state);
  await writeFile(state.configPath, `${raw.trim()}\n`, "utf8");
  await reloadConfig(state);
  pushEvent(state, { type: "config.saved", message: "Config saved" });
  log(state, "config.saved", { configPath: state.configPath });

  if (wasRunning) {
    startMonitor(state);
  }
}

function createMonitor(state) {
  return new TokenMonitor({
    config: state.config,
    notifyFn: async (alert, config) => {
      pushEvent(state, {
        type: "alert",
        status: "alert",
        message: `${alert.symbol} ${alert.chainId}`,
        alert
      });
      const { notify } = await import("./notifier.js");
      await notify(alert, config);
    },
    actionFn: async (alert, config) => {
      const { runActions } = await import("./actions.js");
      return runActions(alert, config);
    }
  });
}

function startMonitor(state) {
  if (state.running) {
    return;
  }

  state.running = true;
  pushEvent(state, { type: "monitor.started", message: "Monitor started" });
  log(state, "monitor.started", { intervalSeconds: state.config.monitor.intervalSeconds });
  scheduleNextRun(state, 0);
}

function stopMonitor(state) {
  state.running = false;
  if (state.timer) {
    clearTimeout(state.timer);
    state.timer = null;
  }
  pushEvent(state, { type: "monitor.stopped", message: "Monitor stopped" });
  log(state, "monitor.stopped", {});
}

function scheduleNextRun(state, delayMs) {
  if (!state.running) {
    return;
  }

  state.timer = setTimeout(async () => {
    await runOnce(state, { source: "scheduled" }).catch((error) => {
      state.lastError = error.message;
      pushEvent(state, { type: "error", status: "error", message: error.message });
      log(state, "run.error", { source: "scheduled", message: error.stack ?? error.message });
    });
    scheduleNextRun(state, state.config.monitor.intervalSeconds * 1000);
  }, delayMs);
}

async function runOnce(state, { source }) {
  if (state.currentRun) {
    return state.currentRun;
  }

  state.currentRun = state.monitor.runOnce()
    .then((results) => {
      state.lastRunAt = new Date().toISOString();
      state.lastError = null;
      pushEvent(state, {
        type: "run.completed",
        status: "ok",
        message: `${source} run checked ${results.length} pair(s)`,
        summary: summarizeResults(results)
      });
      log(state, "run.completed", { source, summary: summarizeResults(results), checked: results.length });
      for (const result of results) {
        if (result.status !== "alert") {
          pushEvent(state, {
            type: "pair.checked",
            status: result.status,
            message: formatResult(result),
            result: compactResult(result)
          });
        }
      }
      return results.map(compactResult);
    })
    .finally(() => {
      state.currentRun = null;
    });

  return state.currentRun;
}

async function log(state, event, payload = {}) {
  const line = JSON.stringify({
    at: new Date().toISOString(),
    event,
    ...payload
  });

  try {
    await mkdir(path.dirname(state.logFile), { recursive: true });
    await writeFile(state.logFile, `${line}\n`, { flag: "a" });
  } catch (error) {
    console.error(`[log failed] ${error.message}`);
  }
}

function serializeStatus(state) {
  return {
    running: state.running,
    busy: Boolean(state.currentRun),
    configPath: state.configPath,
    intervalSeconds: state.config?.monitor?.intervalSeconds,
    dryRun: Boolean(state.config?.monitor?.dryRun),
    targets: state.config?.targets ?? [],
    chains: Object.keys(state.config?.chains ?? {}),
    lastRunAt: state.lastRunAt,
    lastError: state.lastError,
    gmgnApiKeyConfigured: Boolean(state.config?.gmgn?.apiKey),
    eventCount: state.events.length,
    recentEvents: state.events.slice(0, 20)
  };
}

function compactResult(result) {
  if (result.status === "skipped") {
    return {
      status: result.status,
      reason: result.reason,
      target: result.target,
      pair: result.pair ?? null
    };
  }

  return {
    status: result.status,
    target: result.target,
    pair: {
      chainId: result.pair.chainId,
      dexId: result.pair.dexId,
      pairAddress: result.pair.pairAddress,
      symbol: result.pair.symbol,
      tokenAddress: result.pair.baseToken?.address ?? null,
      priceUsd: result.pair.priceUsd,
      volumeH1Usd: result.pair.volumeH1Usd,
      marketCapUsd: result.pair.marketCapUsd,
      liquidityUsd: result.pair.liquidityUsd,
      holderCount: result.pair.holderCount,
      swapsH1: result.pair.swapsH1,
      source: result.pair.source,
      url: result.pair.url
    },
    walletStats: result.walletStats,
    evaluation: result.evaluation,
    alert: result.alert
  };
}

function summarizeResults(results) {
  return results.reduce((acc, result) => {
    acc[result.status] = (acc[result.status] ?? 0) + 1;
    return acc;
  }, {});
}

function formatResult(result) {
  if (result.status === "skipped") {
    return `${result.target?.label ?? "target"} skipped: ${result.reason}`;
  }

  return `${result.status.toUpperCase()} ${result.pair.symbol} ${result.pair.chainId} volume=${result.pair.volumeH1Usd} cap=${result.pair.marketCapUsd} wallets=${result.walletStats.uniqueWallets}`;
}

function pushEvent(state, event) {
  state.events.unshift({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    at: new Date().toISOString(),
    ...event
  });
  state.events = state.events.slice(0, MAX_EVENTS);
}

function sanitizeConfig(config) {
  return JSON.parse(JSON.stringify(config ?? {}));
}

async function serveStatic(request, response, pathname) {
  const normalized = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.resolve(PUBLIC_DIR, `.${normalized}`);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  try {
    const body = await readFile(filePath);
    response.writeHead(200, { "content-type": contentType(filePath) });
    response.end(body);
  } catch {
    response.writeHead(404);
    response.end("Not found");
  }
}

function contentType(filePath) {
  if (filePath.endsWith(".html")) return "text/html; charset=utf-8";
  if (filePath.endsWith(".css")) return "text/css; charset=utf-8";
  if (filePath.endsWith(".js")) return "text/javascript; charset=utf-8";
  return "application/octet-stream";
}

async function readJson(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
}

function sendJson(response, status, data) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(data));
}

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--config" || arg === "-c") {
      args.config = argv[++index];
    } else if (arg === "--port" || arg === "-p") {
      args.port = argv[++index];
    } else if (arg === "--host") {
      args.host = argv[++index];
    } else if (arg === "--log-file") {
      args.logFile = argv[++index];
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  return args;
}

main().catch((error) => {
  console.error(error.stack ?? error.message);
  process.exitCode = 1;
});
