import { spawn } from "node:child_process";

export async function runActions(alert, config) {
  const trade = config.actions?.trade;

  if (!trade?.enabled) {
    return [];
  }

  const dryRun = config.monitor?.dryRun || trade.mode !== "live";
  const action = buildTradeAction(alert, trade, dryRun);

  if (dryRun) {
    if (config.actions?.trade?.logDryRun !== false) {
      console.log(`[DRY-RUN ACTION] trade action prepared for ${alert.symbol} ${alert.chainId}:${alert.pairAddress}`);
    }
    return [action];
  }

  await runTradeCommand(alert, trade);
  return [action];
}

export function buildTradeAction(alert, trade, dryRun) {
  return {
    type: "trade",
    mode: dryRun ? "dry-run" : "live",
    command: trade.command || null,
    args: trade.args ?? [],
    alert
  };
}

export async function runTradeCommand(alert, trade) {
  if (!trade.command) {
    throw new Error("Trade action is live but command is empty");
  }

  await new Promise((resolve, reject) => {
    const child = spawn(trade.command, trade.args ?? [], {
      stdio: ["pipe", "inherit", "inherit"]
    });
    const timeout = setTimeout(() => {
      child.kill("SIGTERM");
      reject(new Error(`Trade command timed out after ${trade.timeoutMs ?? 30_000}ms`));
    }, trade.timeoutMs ?? 30_000);

    child.on("error", (error) => {
      clearTimeout(timeout);
      reject(error);
    });

    child.on("exit", (code, signal) => {
      clearTimeout(timeout);
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Trade command failed with code=${code} signal=${signal ?? ""}`));
      }
    });

    if (trade.passAlertJsonOnStdin !== false) {
      child.stdin.end(JSON.stringify(alert));
    } else {
      child.stdin.end();
    }
  });
}
