const BASE_URL = "https://api.dexscreener.com";

export class DexScreenerClient {
  constructor({ fetchImpl = fetch, baseUrl = BASE_URL, timeoutMs = 15_000 } = {}) {
    this.fetchImpl = fetchImpl;
    this.baseUrl = baseUrl;
    this.timeoutMs = timeoutMs;
  }

  async getPair(chainId, pairAddress) {
    const data = await this.#get(`/latest/dex/pairs/${encodeURIComponent(chainId)}/${encodeURIComponent(pairAddress)}`);
    return Array.isArray(data?.pairs) ? data.pairs[0] ?? null : null;
  }

  async getTokenPairs(chainId, tokenAddress) {
    const data = await this.#get(`/token-pairs/v1/${encodeURIComponent(chainId)}/${encodeURIComponent(tokenAddress)}`);
    return Array.isArray(data) ? data : [];
  }

  async getLatestBoostedTokens() {
    const data = await this.#get("/token-boosts/latest/v1");
    return Array.isArray(data) ? data : [];
  }

  async #get(path) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
        headers: { accept: "application/json" },
        signal: controller.signal
      });

      if (!response.ok) {
        const text = await response.text().catch(() => "");
        throw new Error(`DexScreener request failed (${response.status}): ${text.slice(0, 300)}`);
      }

      return response.json();
    } finally {
      clearTimeout(timeout);
    }
  }
}

export function normalizePair(pair) {
  if (!pair) return null;

  const baseSymbol = pair.baseToken?.symbol ?? "BASE";
  const quoteSymbol = pair.quoteToken?.symbol ?? "QUOTE";
  const marketCapUsd = numberOrNull(pair.marketCap ?? pair.fdv);

  return {
    chainId: pair.chainId,
    dexId: pair.dexId,
    pairAddress: pair.pairAddress,
    baseToken: pair.baseToken ?? null,
    quoteToken: pair.quoteToken ?? null,
    symbol: `${baseSymbol}/${quoteSymbol}`,
    priceUsd: numberOrNull(pair.priceUsd),
    volumeH1Usd: numberOrNull(pair.volume?.h1),
    marketCapUsd,
    fdvUsd: numberOrNull(pair.fdv),
    liquidityUsd: numberOrNull(pair.liquidity?.usd),
    url: pair.url,
    raw: pair
  };
}

export function sortPairsByH1Volume(pairs) {
  return [...pairs].sort((a, b) => (numberOrNull(b.volume?.h1) ?? -1) - (numberOrNull(a.volume?.h1) ?? -1));
}

function numberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
