import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

const CHAIN_TO_GMGN = {
  ethereum: "eth",
  bsc: "bsc",
  solana: "sol",
  sol: "sol",
  eth: "eth"
};

export async function discoverGmgnTrendingTargets({ config }) {
  const source = config.discovery?.gmgnTrending;
  if (!source?.enabled) {
    return [];
  }

  if (!hasGmgnApiKey(config)) {
    throw new Error("GMGN_API_KEY is required. Fill GMGN API Key in Candidate Source or set GMGN_API_KEY in the environment.");
  }

  const chains = source.chains?.length ? source.chains : Object.keys(config.chains ?? {});
  const groups = await Promise.all(chains.map((chainId) => fetchGmgnTrending({ chainId, source, config })));
  return groups.flat();
}

export async function discoverGmgnTrendingPairs({ config }) {
  const source = config.discovery?.gmgnTrending;
  if (!source?.enabled) {
    return [];
  }

  if (!hasGmgnApiKey(config)) {
    throw new Error("GMGN_API_KEY is required. Fill GMGN API Key in Candidate Source or set GMGN_API_KEY in the environment.");
  }

  const chains = source.chains?.length ? source.chains : Object.keys(config.chains ?? {});
  const groups = await Promise.all(chains.map((chainId) => fetchGmgnTrendingRows({ chainId, source, config })));
  return groups.flat();
}

async function fetchGmgnTrending({ chainId, source, config }) {
  const rows = await fetchGmgnTrendingRows({ chainId, source, config });

  return rows
    .map((row, index) => toTarget({ row, chainId, index }))
    .filter(Boolean);
}

async function fetchGmgnTrendingRows({ chainId, source, config }) {
  const gmgnChain = source.chainMap?.[chainId] ?? CHAIN_TO_GMGN[chainId] ?? chainId;
  const command = config.gmgn?.cliCommand ?? source.command ?? "gmgn-cli";
  const args = [
    "market",
    "trending",
    "--chain",
    gmgnChain,
    "--interval",
    source.interval ?? "1h",
    "--order-by",
    source.orderBy ?? "volume",
    "--limit",
    String(source.limit ?? 50),
    "--raw"
  ];

  for (const filter of source.filters ?? []) {
    args.push("--filter", filter);
  }

  const { stdout } = await execFileAsync(command, args, {
    timeout: source.timeoutMs ?? 30_000,
    env: buildEnv(config)
  });
  const rows = normalizeGmgnRows(JSON.parse(stdout));

  return rows
    .map((row, index) => normalizeGmgnPair({ row, chainId, index }))
    .filter(Boolean);
}

function buildEnv(config) {
  const env = {
    ...process.env,
    ...(config.env ?? {})
  };

  if (hasGmgnApiKey(config)) {
    env.GMGN_API_KEY = config.gmgn.apiKey;
  }

  return env;
}

function hasGmgnApiKey(config) {
  return typeof config.gmgn?.apiKey === "string"
    && config.gmgn.apiKey.trim() !== ""
    && !/^\$\{.+\}$/.test(config.gmgn.apiKey.trim());
}

export function normalizeGmgnRows(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.data?.list)) return payload.data.list;
  if (Array.isArray(payload?.data?.rank)) return payload.data.rank;
  if (Array.isArray(payload?.result)) return payload.result;
  if (Array.isArray(payload?.tokens)) return payload.tokens;
  return [];
}

export function normalizeGmgnPair({ row, chainId, index }) {
  const tokenAddress = firstString(row, [
    "address",
    "token_address",
    "tokenAddress",
    "base_address",
    "baseAddress",
    "ca",
    "contract_address",
    "contractAddress"
  ]);
  const pairAddress = firstString(row, [
    "pair_address",
    "pairAddress",
    "pool_address",
    "poolAddress",
    "pool"
  ]);

  if (!tokenAddress && !pairAddress) {
    return null;
  }

  const symbol = row.symbol ?? row.name ?? `GMGN-${index + 1}`;

  return {
    chainId,
    dexId: "gmgn",
    pairAddress: pairAddress ?? tokenAddress,
    baseToken: {
      address: tokenAddress ?? pairAddress,
      symbol
    },
    quoteToken: null,
    symbol,
    priceUsd: numberOrNull(row.price),
    volumeH1Usd: numberOrNull(row.volume ?? row.volume_1h ?? row.volume1h),
    marketCapUsd: numberOrNull(row.market_cap ?? row.usd_market_cap ?? row.marketCap),
    fdvUsd: numberOrNull(row.fdv),
    liquidityUsd: numberOrNull(row.liquidity),
    holderCount: numberOrNull(row.holder_count ?? row.holderCount),
    swapsH1: numberOrNull(row.swaps ?? row.swaps_1h ?? row.swaps1h),
    url: tokenAddress ? `https://gmgn.ai/${chainId === "solana" ? "sol" : chainId}/token/${tokenAddress}` : null,
    raw: row,
    source: "gmgnTrending"
  };
}

function toTarget({ row, chainId, index }) {
  const tokenAddress = firstString(row, [
    "address",
    "token_address",
    "tokenAddress",
    "base_address",
    "baseAddress",
    "ca",
    "contract_address",
    "contractAddress"
  ]);
  const pairAddress = firstString(row, [
    "pair_address",
    "pairAddress",
    "pool_address",
    "poolAddress",
    "pool"
  ]);

  if (!tokenAddress && !pairAddress) {
    return null;
  }

  return {
    label: `gmgn:${chainId}:${row.symbol ?? row.name ?? index + 1}`,
    enabled: true,
    chainId,
    tokenAddress: tokenAddress ?? "",
    pairAddress: pairAddress ?? "",
    source: "gmgnTrending"
  };
}

function firstString(source, keys) {
  for (const key of keys) {
    const value = source?.[key];
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return null;
}

function numberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
