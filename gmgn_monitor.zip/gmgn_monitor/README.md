# Onchain Token Watch

一个链上代币监控 CLI，支持 Ethereum、BSC、Solana：当某个交易池在最近 1 小时同时满足下面条件时发出提醒：

- 1h 交易额 `> 2,000,000 USD`
- 代币市值 `< 10,000,000 USD`
- 1h 独立交易钱包数 `> 1,000`

行情数据来自 DexScreener。EVM 链的独立钱包数通过 RPC 扫描交易池 `Swap` 日志后按交易 `from` 地址去重统计；Solana 的独立钱包数通过 RPC 扫描池地址近 1 小时交易签名后按 fee payer 去重统计。

## 快速开始

需要 Node.js 20 或以上。

```bash
cp config.example.json config.json
node src/index.js --config config.json --once
```

示例配置已经内置公开 RPC：

- Ethereum: `https://ethereum-rpc.publicnode.com`
- BSC: `https://bsc-rpc.publicnode.com`
- Solana: `https://api.mainnet-beta.solana.com`

如果你设置了 `ETHEREUM_RPC_URL`、`BSC_RPC_URL`、`SOLANA_RPC_URL`，程序会优先使用你的专用 RPC。

常驻监控：

```bash
node src/index.js --config config.json
```

启动本地 Web 控制台：

```bash
npm run web
```

默认地址是 `http://127.0.0.1:8787`。也可以指定配置和端口：

```bash
node src/web.js --config config.json --port 8787
```

Web 控制台可以查看状态、编辑配置、保存配置、运行一次监控、启动/停止后台监控、查看最近事件和告警。

配置里可以写 `tokenAddress` 或 `pairAddress`：

```json
{
  "targets": [
    {
      "label": "My token",
      "enabled": true,
      "chainId": "ethereum",
      "tokenAddress": "0x..."
    },
    {
      "label": "My pool",
      "enabled": true,
      "chainId": "solana",
      "pairAddress": "0x..."
    }
  ]
}
```

如果写 `tokenAddress`，程序会调用 DexScreener 的 token-pairs 接口，默认检查 1h 交易额最高的前 3 个池子。
示例配置里的目标默认 `enabled: false`，把地址和开关改好后再运行。

## 提醒方式

默认打印到控制台。也可以配置 Telegram：

```bash
export TELEGRAM_BOT_TOKEN="123456:bot-token"
export TELEGRAM_CHAT_ID="123456789"
node src/index.js --config config.json
```

```json
{
  "notifiers": {
    "telegram": {
      "enabled": true,
      "botToken": "${TELEGRAM_BOT_TOKEN}",
      "chatId": "${TELEGRAM_CHAT_ID}",
      "disableWebPagePreview": true
    }
  }
}
```

也可以配置通用 webhook：

```json
{
  "notifiers": {
    "webhook": {
      "enabled": true,
      "url": "${ALERT_WEBHOOK_URL}",
      "method": "POST",
      "headers": {
        "content-type": "application/json"
      }
    }
  }
}
```

## 修改参数与扩展条件

默认阈值在 `thresholds` 中：

```json
{
  "thresholds": {
    "minVolumeH1Usd": 2000000,
    "maxMarketCapUsd": 10000000,
    "minUniqueWalletsH1": 1000
  }
}
```

每条链可以覆盖自己的阈值。比如 BSC 和 Solana 使用不同条件：

```json
{
  "chains": {
    "ethereum": {
      "kind": "evm",
      "rpcUrl": "${ETHEREUM_RPC_URL:-https://ethereum-rpc.publicnode.com}",
      "thresholds": {
        "minVolumeH1Usd": 2000000,
        "maxMarketCapUsd": 10000000,
        "minUniqueWalletsH1": 1000
      }
    },
    "bsc": {
      "kind": "evm",
      "rpcUrl": "${BSC_RPC_URL:-https://bsc-rpc.publicnode.com}",
      "thresholds": {
        "minVolumeH1Usd": 1500000,
        "maxMarketCapUsd": 8000000,
        "minUniqueWalletsH1": 800
      }
    },
    "solana": {
      "kind": "solana",
      "rpcUrl": "${SOLANA_RPC_URL:-https://api.mainnet-beta.solana.com}",
      "thresholds": {
        "minVolumeH1Usd": 2500000,
        "maxMarketCapUsd": 12000000,
        "minUniqueWalletsH1": 1200
      }
    }
  }
}
```

如果某条链要完全不同的条件，也可以在链配置里写 `conditions`。目标级 `target.conditions` 优先级最高，其次是 `chains.<chainId>.conditions`，最后才是全局 `conditions`。

临时运行时覆盖参数：

```bash
node src/index.js --config config.json --set thresholds.minVolumeH1Usd=3000000 --set monitor.intervalSeconds=60
node src/index.js --config config.json --set chains.solana.thresholds.minVolumeH1Usd=5000000
```

`conditions` 是可扩展条件列表。默认三条件等价于：

```json
[
  {
    "id": "volume",
    "label": "1h volume",
    "metric": "volumeH1Usd",
    "operator": ">",
    "valueFrom": "thresholds.minVolumeH1Usd"
  },
  {
    "id": "marketCap",
    "label": "market cap",
    "metric": "marketCapUsd",
    "operator": "<",
    "valueFrom": "thresholds.maxMarketCapUsd"
  },
  {
    "id": "uniqueWallets",
    "label": "1h unique wallets",
    "metric": "uniqueWalletsH1",
    "operator": ">",
    "valueFrom": "thresholds.minUniqueWalletsH1"
  }
]
```

以后可以追加条件，例如要求流动性至少 `500,000 USD`：

```json
{
  "id": "liquidity",
  "label": "liquidity",
  "metric": "liquidityUsd",
  "operator": ">=",
  "value": 500000
}
```

目前支持的指标包括 `volumeH1Usd`、`marketCapUsd`、`fdvUsd`、`liquidityUsd`、`priceUsd`、`uniqueWalletsH1`。支持的操作符包括 `>`、`>=`、`<`、`<=`、`==`、`!=`、`exists`。

## 预留下单动作

`actions.trade` 预留给满足条件后的下单动作。默认关闭，且默认是 `dry-run`，不会执行真实交易：

```json
{
  "actions": {
    "trade": {
      "enabled": true,
      "mode": "dry-run",
      "command": "",
      "args": [],
      "passAlertJsonOnStdin": true,
      "timeoutMs": 30000,
      "logDryRun": true
    }
  }
}
```

未来接入真实下单时，把 `mode` 改成 `live` 并配置一个独立交易脚本命令。程序会把告警 JSON 通过 stdin 传给该脚本。建议交易脚本自行实现白名单、单笔上限、每日上限、滑点上限和急停开关。

Webhook body 格式：

```json
{
  "type": "token-watch.alert",
  "alert": {
    "chainId": "ethereum",
    "pairAddress": "0x...",
    "symbol": "TOKEN/WETH",
    "volumeH1Usd": 2300000,
    "marketCapUsd": 8000000,
    "uniqueWalletsH1": 1200,
    "url": "https://dexscreener.com/..."
  }
}
```

## 重要限制

- 统计口径是“最近 1 小时内触发池子 Swap 的交易 `from` 地址去重数”。这比 DexScreener 的买卖次数更接近“独立钱包”，但代理合约、聚合器、AA 钱包会影响最终含义。
- Solana 统计口径是“最近 1 小时内触达池地址的交易 fee payer 去重数”，这是可运行的近似值；Raydium/Orca/Jupiter 等路径下，真实 trader 与 fee payer 可能不完全一致。
- 默认识别 Uniswap V2/V3 兼容池子的 `Swap` 事件；Curve、Balancer 或自定义 DEX 需要扩展事件解析。
- 不建议无目标地全链扫描新币。生产环境如果要覆盖所有新池，需要接入专业索引器或自建事件索引。
- 公开 RPC 适合试跑和低频监控，可能限流或不稳定；长期运行建议换成专用 RPC，并通过环境变量覆盖。
- 下单功能目前是执行器占位，不包含私钥管理和真实 swap 逻辑；接入真实交易前必须做小额测试和风控审查。
- 行情接口参考 DexScreener API：<https://docs.dexscreener.com/api/reference>

## 测试

```bash
npm test
```
